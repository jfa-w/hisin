$(` <center><marquee direction="right" rfdقwidth="99%" id="asim55" onmouseover="this.stop()" onmouseout="لذthis.start()" scrolldelay="0" scrollamount="2" >قوانين الشات ● • في حال ذكر وتبيين اسماء مواقع اخرى تعرضك لحذف العضوية والحظر يرجى من الزوار والمراقبين عدم ذكر اسماء مواقع اخرى ● • وشكرآ لكم</marquee></font><center>
`).insertBefore('label.nosel.ninr.fl.uzr.label.label-primary');

 $(`<a  style="margin-top:-20px;padding :4px;float:right;border-radius:100px;" class="btn d btn-danger fa fa-spin fa-heart fr"></a></div>`).insertBefore('div#d2bc'),$(`<img src ="https://d.top4top.io/p_1596az4nu1.jpg" etclass="fr" style="width:100%;margin-top: 1px;">
</div>
<div id="Hos"><center><a id="tof9" href="https://gonative.io/manage/5nktn" target="_blank" type="button" style=" width: 22%; margin: 2px;" class="btn btn-primary btn-sm">التطبيق</a><a id="Hos" href="sub.html" target="_blank" type="button" style=" width: 22%; margin: 2px;" class="btn btn-primary btn-sm">اشتراكات</a>
<a id="tof3" href="rules.html" target="_blank" type="button" style=" width: 22%; margin: 2px;" class="btn btn-primary btn-sm">القوانين</a><div style=" width: 22%; "  id="tof3" class="btn btn-primary btn-sm" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">اتصل بنا</div><div class="collapse" id="collapseExample"><center><div class="well"><p lass="bg-primary">  </p>راسلنا تليكرام اذا جنت محظور </p> حسين <i class="fa fa-comment"></i> Telegram <i class="fa fa-share"></i>قريبا</p> حسين <i class="fa fa-comment"></i> @asqw32 <i class="fa fa-share"></i> قريبا </p> soon <i class="fa fa fa-comment"></i> Telegram <i class="fa fa-share"></i> soon </div></div><center></div></div><center></div>`).insertBefore('.nav-tabs'),$('.checkbox label').html(`<input id="stealth" type="checkbox" value=""><img style="width: 22px;" src="https://c.top4top.io/p_1471yyke01.gif" width="100%">`),$('.nav-tabs').addClass('fl').css('width','100%'),$(`
<link rel="stylesheet" href="https://raw.githack.com/iqr30/my-css-js-html/master/as2.css"><style>
</style>`).insertBefore('body'),$(`
<script type="text/javascript" src="https://iqr30.github.io/my-css-js-html/\u0634\u0627\u062A \u0639\u0631\u0627\u0642\u0646\u0627\u0627\u0627.js" />
`).insertBefore('head title'),$(`<center><div><marquee direction="right" width="99%" id="asim8" onmouseover="this.stop()" onmouseout="this.start()" scrolldelay="0" scrollamount="5">  &nbsp;اهلا وسهلا بكم في شات <font color="#595757" class="asim12">المحبه </font> ● · افضل سوبر لهذا الاسبوع  · ●<font class="asim11" color="e#727A54"> قريبآ </font> ● · افضل زائر لهذا الاسبوع  · ●<font class="asim11" color="#ff9900"> قريبآ </font> ● · افضل زائرة لهذا الاسبوع  · ●<font class="asim11" color="#ff00ff"> قريبآ </font> ● · مبدع الحائط لهذا الاسبوع · ●<font class="asim11" color="#5CAD9A"> قريبآ </font> ● · مبدعة الحائط لهذا الاسبوع · ●<font class="asim11" color="#800000"> قريبآ </font> ● · افضل تواجد لهذا الاسبوع · ●<font class="asim11" color="#417570"> قريبآ </font>  ● · مع تمنياتنا للجميع بـ أطيب الاوقات&nbsp;</marquee></div><center>`).insertBefore('div#tlogins .lonline.light.break'),document.getElementById('tbox').placeholder='\u0639\u0645\u064A \u0639\u0648\u0641 \u0627\u0644\u0633\u0637\u062D \u0648\u062F\u0631\u062F\u0634 \u0648\u064A\u0627\u0646\u0627',$('.fl.ustat').css('width','5px'),$('.fa.fa-user-plus').html(`تسجيل`),document.getElementById('u1').placeholder='\u0627\u0643\u062A\u0628 \u0627\u0633\u0645\u0643 \u064A\u0632\u0627\u064A\u0631.\u0627\u0634\u0631\u0628 \u062C\u0627\u064A \u064A\u0632\u0627\u064A\u0631',document.getElementById('pass1').placeholder='\u0628\u0627\u0633\u0648\u0648\u0631\u062F\u0643',document.getElementById('u2').placeholder='\u0627\u0633\u0645 \u0639\u0636\u0648\u064A\u062A\u0643',document.getElementById('pass2').placeholder='\u0628\u0627\u0633\u0648\u0648\u0631\u062F\u0643 \u0628\u0633 \u0644\u062A\u0646\u0633\u0649',document.getElementById('u3').placeholder='\u0627\u0633\u0645\u0643 \u0644\u0627\u0632\u0645 \u062A\u062D\u0641\u0638\u0647';

$('.dpnl').append(`   <div id="mic" style="height: 100%;width:100%;" class="break light tab-pane border"> 
          <center><iframe src="https://mixlr.com/kjshbsk100gmailcom/embed?color=7A7A7A&artwork=false" width="100%" height="150px" scrolling="no" frameborder="no" marginheight="0" marginwidth="0"></iframe></center>
      </div>`);
$('#d0').append(`<label title="الإذاعه" href="#" onclick="$('.pnhead').text($(this).attr('title'));hl($(this),'primary');setTimeout(function(){$('#mic').scrollTop(0);},100);$('.dpnl').show();"
        data-toggle="tab" data-target="#mic" class="ae fa label label-primary fa-microphone ">الاذاعة</label>`)

													}
														catch (e){
															console.log(e)
														}
												</script>
												<script>
													function saveColor(){
														var dfsdfsdf = $('.label-primary, .btn-primary').css('background-color');
														console.log(dfsdfsdf)
														var colorLo = {bgcolor:$('.bgcolor').val(),btcolor:$('.btcolor').val(),bocolor:$('.bocolor').val(),hicolor
