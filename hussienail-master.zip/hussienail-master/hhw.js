$(`<img src="https://g.top4top.io/p_1580ydbxa1.jpg
" class="fr" style="width:100%;margin-right: 2px;">
<a id="des3" href="https://alahappa.blogspot.com/2020/05/httpsalahappa.html" style="border-radius: 24px;width:23%;margin:2px;" class="fl mini  fa  fa-facebook
 btn btn-primary"> مدونه شات</a>
<a id="des3" href="https://raw.githack.com/hussienail/hussienail/master/2%D8%B4%D8%AA%D8%B1.html
" style="border-radius: 24px;width:23%;margin:2px;" class="fl mini  fa   fa-star
 btn btn-default"> ميز نفسك</a>
<a id="des3" href="https://raw.githack.com/hussienail/hussienail/master/11قوانين .html" style="border-radius: 24px;width:27%;margin:2px;" class="fl mini  fa fa-graduation-cap
btn btn-primary"> قوانين موقع</a>
<a id="des3" href="https://raw.githack.com/hussienail/hussienail/master/تصل بنا8 .html" style="border-radius: 24px;width:22%;margin:2px;" class="fl mini  fa fa-phone
btn btn-default"> اتصل بنا</a>
<div style="width:100%;"  id="" class="btn btn-primary btn-ali" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">إدآرة ألمـؤقع </div>
<div class="collapse" id="collapseExample"><center><div class="well"><p lass="bg-primary">  </p>     صـآإحب إلـمـوقـع / ♪ حسين النعيمي </p> <i class="fa fa-"></i>  
<a href="#" style="border-radius: 90px 90px 90px 90px;width:48%;margin:2px;" class="fl mini  fa   fa-heartbeat
 btn btn-primary"> .. المحبه  .. </a>
<a href="#" style="border-radius: 90px 90px 90px 90px;width:49%;margin:2px;p dir="ltr" align="center" class="fl mini  fa fa-star
btn btn-primary"> .. شات  ..  </a>
 <center></div></div></div>
`).insertBefore('.nav-tabs');
$('.nav-tabs').addClass('fl').css('width','100%');
$('a[href="https://jawalhost.com/"]').removeAttr('href');
$( "button.btn.btn-primary" ).css( "border-radius", "24px 24px 24px 24px" );
$(".border.corner").css("border-radius","24px 24px 24px 24px");


$(`<center><div><div width="75.5%" style="background-color:#91876E; color: #91876E;border-radius: 5px 5px 5px5px;border-bottom: 2px solid #ffffff;border-top: 2px solid#ffffff;padding-bottom: 2px!important;"  
><font style="background-color: #fff;border-radius: 0px 25px 0px 25px;font-family: 'Cairo', sans-serif, FontAwesome;padding: 2px 10px 2px 10px; margin:0px 25px 0px 25px;" >اهلآ وسهلاً بكم فِي شآت المحبه  للجوال   </font></div></div><center>`).insertBefore('#d2');

$
$(`<div><marquee direction="right" width="100%" id="des1" onmouseover="this.stop()" onmouseout="this.start()" scrolldelay="0" scrollamount="5">🌸 ادارة الموقع ترحب بكم   🌸 اهلا وسهلا بكم في شات المحبه  </marquee></div>`).insertBefore('div#tlogins .lonline.light.break');

$(`<link rel="stylesheet" type="text/css" href="//www.fontstatic.com/f=jazeera" />
<link rel="stylesheet" href="//alshela.net/alshelh.css">
<style>
.fitimg.fl.u-pic  {box-shadow: 0 1px 1px -1px  rgb(0, 95, 105), 0 0 6px rgb(0, 95, 105);border-radius: 4px 4px 4px 4px;;}
textarea.fl.filw.corner.tbox {border-radius: 10px;padding-left: 5px;border: 2px solid #005F69;margin-top: 2px;}
.label.tc.border.btn.fl, .label.tc.border.btn.fl {border: 2px solid #adadad;font-family: 'jazeera',FontAwesome;border-radius: 24px 24px 24px 24px;}
</style>`).insertBefore('body');
$(`<img style="height:50px;width: 100%;margin-right: 5px;background-color: #DE9DA5;" src="https://f.top4top.io/p_158131obv1.gif" border="0">`).insertBefore('div#d2bc');
$(".fa-gear").text("الاعدادات ").css("width","");
$(".dpnl").append(`<div id="mic"style="text-align: center;font-family: el messiri,FontAwesome!important;color: #610A00; height: 100%;width:100%;"class="break light tab-pane border">نتمنى لكم اجمل وقات</BR><p> للطربكه وركص شغل </p></p><iframe width="77%" height="30%" src="https://www.youtube.com/embed/OFeNwGOjaK4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></p><img src="https://g.top4top.io/p_1572nrhl21.gif"style="width:%;margin-top: 0px;"></BR></BR> </BR><center></div><center></div>`), $('#d0').append(`<label title="مقهى المحبه"href="#"onclick="$('.pnhead').text($(this).attr('title'));hl($(this),'primary');setTimeout(function(){$('#mic').scrollTop(0);},0);$('.dpnl').show();"data-toggle="tab"data-target="#mic"class="ae fa label label-primary fa-tv"> </label>`);
