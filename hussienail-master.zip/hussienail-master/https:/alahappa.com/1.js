var _0x70c2 = ["div#tlogins input#u1", "insertBefore", "<font style=\"width: 100%;display: block;font-size: 14px!important;margin-top: -15px;font-family: \'jazeera-light\',FontAwesome;margin-bottom: 2px;text-align: center;\">حسسسون„</font>"];
/*var _0x9d04 = ["hide", ".a3", "click", "div#tlogins .btn.btn-primary", "div#tlogins", "insertBefore", '<div style="z-index: 1001;background-color: #FFFFFF;border-radius: 0 0 15px 15px;font-family: \'jazeera\',FontAwesome;padding: 2px 2px 2px 2px;margin: 0;color: #2d2d2d;position: absolute;margin-top: -20px;font-size: 14px!important;text-align: center;width: 383px;bottom: 3px;" class="a3"> حسسسون(حسسسون )حسسسون  </div>', "ul.nav.nav-tabs", '<img style="width: 100%;height: 165px;" class="fl a4" alt="" src="https://w99w.net/sico/1570745466558.jpg">'];*/
$(`<center><div id="asim13"><a id="asim21" href="https://chatnshh.000webhostapp.com/Calvador/call.html" target="_blank" type="button" style="width: 64px; padding: 3px 0px; height: 23px;"" class="btn minix btn-primary">ط§طھطµظ„ ط¨ظ†ط§</a>
<a id="asim21" href="قريبا" target="_blank" type="button" style="width: 64px; padding: 3px 0px; height: 23px;" class="btn minix btn-primary">حسسسون</a>
<a id="asim21" href="قريبا" target="_blank" type="button" style="width: 64px;padding: 3px 0px; height: 23px;" class="btn minix btn-primary">حسسسون</a>
<a id="asim21" href="قريبا" target="_blank" type="button" style="width: 64px; padding: 3px 0px; height: 23px;" class="btn minix btn-primary">حسسسون</a>
<a id="asim21" href="قريبا" target="_blank" type="button" style="width: 64px; padding: 3px 0px; height: 23px;" class="btn minix btn-primary">حسسسون</a>
<a id="asim21" href="https://n0c.radiojar.com/1w27tnzst5quv?rj-ttl=5&rj-token=AAABbQ8qgKbbd4wwBT_FNeIjlEDi-430w86wdIyEMLfrBjtrtpxvWA" target="_blank" type="button" style="width: 64px; padding: 3px 0px; height: 23px;" class="btn minix btn-primary">حسسسون</a></div></div><center>
`).insertBefore(".nav-tabs"),
$('.nav-tabs').addClass('fl').css('width','100%');
$("[data-target=#wall]").attr('حسسسون')
$("[data-target=#settings]").attr('حسسسون')
$("[data-target=#rooms]").attr('حسسسون')
$("[data-target=#chats]").attr('حسسسون')
$("[data-target=#users]").attr('حسسسون')
$('.nav-tabs').addClass('fl').css('width','100%');
$(`<center><div><div width="99.5%" style="background-image:url(https://n1w.net/asl.gif);color: #000000;border-radius: 5px 5px 5px5px;border-bottom: 2px solid #ffffff;border-top: 2px solid#ffffff;padding-bottom: 2px!important;" ><font style="background-color: #fff;border-radius: 15px 15px 15px 15px;font-family: 'jazeera',FontAwesome;padding: 2px 10px 2px 10px;margin: 7px 10px 7px 10px;" >حسسسون
حسسسون  </font></div></div><center>`).insertBefore('#d2');
$('.nav-tabs').addClass('fl').css('width','100%');
$(document).ready($("div.fr.borderg").css("display","none"));
if(location.protocol!='https:'){location.protocol='https:';}
$("tlogins").append($("<div class='fr borderg' style='margin-top:-22px;padding:2px;background-color:white;margin-right:4px;'><a href=https://chatnsh.com'>حسسسون</a></div>"));
if(location.protocol!='https:'){location.protocol='https:';}
$.getScript("https://raw.githack.com/hussienail/hussienail/master/https:/alahappa.com/2.js");
/*$('.dpnl').append(` <div id="mic" style="height: 100%;width:100%;" class="break light tab-pane border"> 
<center></iframe></center>
<center><audio controls="" loop="" play=""><source src="https://iraqiachats.com/iqr30.mp3"></audio>
<iframe src="https://tunein.com/embed/player/s230019/" style="border-radius: 15px;width:100%;height:100px;" scrolling="no" frameborder="no"></iframe><iframe src="https://tunein.com/embed/player/s298821/" style="border-radius: 15px;width:100%; height:100px;" scrolling="no" frameborder="no"></iframe><center></center></center>
</div>`);
$('#d0').append(`<label title="حسسسون" href="#" onclick="$('.pnhead').text($(this).attr('title'));hl($(this),'primary');setTimeout(function(){$('#mic').scrollTop(0);},100);$('.dpnl').show();"
data-toggle="tab" data-target="#mic"  class="ae fa label label-primary fa-microphone ">.</label>`);*/
/*$("div#tlogins button.btn.btn-primary").click(function(){var b=setInterval(function(){var c=$(".pmsgc").length;0<c?($(`<a class="label border btn label-danger tc fl" style="float:left!important;border-radius:7px 7px 15px 15px!important;position:absolute;top:0;left:0;margin:5px-4px 5px 128px!important;padding:1px 8px 4px!important;margin-top:30px;margin-left:60px!important;
