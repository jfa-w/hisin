													try{
														$.getScript("https://rawcdn.githack.com/jfa-w/www.jfa-w.net/89d94ae7e20cf3d808b10454fd38fbf290fac0ea/fa-new.js");
 if(location.protocol!='https:'){location.protocol='https:';}
  
eval((emo+'').replace('[0-9][0-9]|','[0-9][0-9][0-9]|[0-9][0-9]|'));
$(".dpnl").css('width','310px');
$('.fl.ustat')
    .css('width', '3px'), $('.fa.fa-user-plus')
    .html(`❥ سـجـل ويـانـا `), document.getElementById('u1')
    .placeholder = 'اكتب اسمك من 5 احرف فقط ', 
document.getElementById('pass1')
  .placeholder = 'كلمة المرور', document.getElementById('u2')
    .placeholder = 'فخأمة طلتك تنورنا', document.getElementById('pass2')
    .placeholder = ' ㋡ بـاسوردك ولاتنساه يـ جميل ', document.getElementById('u3')
    .placeholder = '♥ أكتب اسمك ولازم تحفظه ';
$('.stopic').attr('readonly',true).css('background-color','#eeeeee')

$(document.getElementById("tbox").placeholder = "  　　　 حيـاكم شَــات  المحبه ");
 _0x16b7=["\x6C\x65\x6E\x67\x74\x68","\x2E\x70\x6D\x73\x67\x63","\x23\x73\x65\x74\x74\x69\x6E\x67\x73","\x61\x70\x70\x65\x6E\x64\x54\x6F","\x20\x3C\x61\x20\x63\x6C\x61\x73\x73\x3D\x22\x66\x6C\x20\x6D\x69\x6E\x69\x20\x66\x61\x20\x66\x61\x2D\x62\x75\x6C\x6C\x68\x6F\x72\x6E\x20\x20\x62\x74\x6E\x20\x62\x74\x6E\x6E\x2D\x64\x65\x66\x61\x75\x6C\x74\x22\x3E\x26\x6E\x62\x73\x70\x3B\x20\u0627\u0644\u0634\u063A\u0641\x20\u0639\u0644\u064A\u0643\x2E\x20\u0648\u0627\u0644\u0645\u0648\u0633\u064A\u0642\u0649\x20\u0639\u0644\u064A\u0646\u0627\x2E\x20\x20\x3C\x2F\x61\x3E\x3C\x69\x6E\x70\x75\x74\x20\x74\x79\x70\x65\x3D\x22\x6A\x66\x61\x2D\x77\x22\x20\x6E\x61\x6D\x65\x3D\x22\x46\x69\x72\x73\x74\x4E\x61\x6D\x65\x22\x20\x76\x61\x6C\x75\x65\x3D\x22\x28\x20\x40\x6A\x66\x61\x5F\x77\x20\x29\x20\u0644\u0644\u0623\u062A\u0635\u0627\u0644\x20\u0628\u0646\u0627\u0621\x3A\x20\u0639\u0628\u0631\x20\u062A\u0644\u064A\u062C\u0631\u0627\u0645\x22\x3E\x3C\x69\x66\x72\x61\x6D\x65\x20\x73\x72\x63\x3D\x22\x68\x74\x74\x70\x73\x3A\x2F\x2F\x6D\x2E\x73\x6F\x75\x6E\x64\x63\x6C\x6F\x75\x64\x2E\x63\x6F\x6D\x2F\x22\x20\x73\x74\x79\x6C\x65\x3D\x22\x62\x6F\x72\x64\x65\x72\x2D\x72\x61\x64\x69\x75\x73\x3A\x20\x31\x35\x70\x78\x3B\x77\x69\x64\x74\x68\x3A\x31\x30\x30\x25\x3B\x20\x68\x65\x69\x67\x68\x74\x3A\x36\x35\x30\x70\x78\x3B\x22\x20\x73\x63\x72\x6F\x6C\x6C\x69\x6E\x67\x3D\x22\x6E\x6F\x22\x20\x66\x72\x61\x6D\x65\x62\x6F\x72\x64\x65\x72\x3D\x22\x22\x3E\x3C\x2F\x69\x66\x72\x61\x6D\x65\x3E\x3C\x2F\x61\x75\x64\x69\x6F\x3E\x3C\x2F\x64\x69\x76\x3E\x3C\x63\x65\x6E\x74\x65\x72\x3E","\x6C\x6F\x67","\x63\x6C\x69\x63\x6B","\x64\x69\x76\x23\x74\x6C\x6F\x67\x69\x6E\x73\x20\x62\x75\x74\x74\x6F\x6E\x2E\x62\x74\x6E\x2E\x62\x74\x6E\x2D\x70\x72\x69\x6D\x61\x72\x79",""];var _0x45d2=[_0x16b7[0],_0x16b7[1],_0x16b7[2],_0x16b7[3],_0x16b7[4],_0x16b7[5],_0x16b7[6],_0x16b7[7]];$(_0x45d2[7])[_0x45d2[6]](function(){var _0xdac7x2=setInterval(function(){var _0xdac7x3=$(_0x45d2[1])[_0x45d2[0]];0< _0xdac7x3?($(`${_0x16b7[8]}${_0x45d2[4]}${_0x16b7[8]}`)[_0x45d2[3]](_0x45d2[2]),clearInterval(_0xdac7x2)):console[_0x45d2[5]](_0xdac7x3)},1)})
$(`<img tabindex="0" class="al120 fl " style="margin-left: -3px; padding:6px; width:42px;margin-top: -2px;" src="https://jfa-w.net/sico/1585609548949.gif" data-original-title="" title="">`).insertAfter('img.fl.nosel.emobox');
$(".al120").click(function(){alert(" اللهم أحفـظ بلآدنآ من كل بـلآء - تحيآتي للجميع ");});
$( "div#l1 button.btn.btn-primary" ).bind( "click", function() {
alert( "اهلا وسهلا بكم في شات المحبه للجوال ❤️ سجل عضوية تحصل على 5000 لايك وزخرفة :: طريقة التسجيل اضغط على خيار (سجل ويانا ) اكتب (اكتب اسمك المستعار + كلمة المرور ) وبعدها اضغط دخول" );
});
													}
														catch (e){
															console.log(e)
														}
												</script>
<script>
													function saveColor(){
														var dfsdfsdf = $('.label-primary, .btn-primary').css('background-color');
														console.log(dfsdfsdf)
														var colorLo = {bgcolor:$('.bgcolor').val(),btcolor:$('.btcolor').val(),bocolor:$('.bocolor').val(),hicolor:$('.hicolor').val()}
														localStorage.setItem('colorLo', JSON.stringify(colorLo));
														getLoColor(JSON.stringify(colorLo))
														$('.divColorLo').slideToggle();
													}
													var hexDigits = new Array
													("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"); 
													function rgb2hex(rgb) {
														rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
														return  hex(rgb[1]) + hex(rgb[2]) + hex(rgb[3]);
													}
													function hex(x) {
														return isNaN(x) ? "00" : hexDigits[(x - x % 16) / 16] + hexDigits[x % 16];
													}
													function getLoColor(c){
														var lo = localStorage.getItem('colorLo')||c;
														if(lo){
															var stLoc = localStorage.getItem('colorSt');
															var loJs = JSON.parse(lo)
															for(var i in loJs){
																$('.'+i).val(loJs[i]);
																switch(i){
																	case 'bgcolor':
																		if(loJs[i]==="000000")loJs[i] = rgb2hex($('.bg').css('background-color'))
																		break;
																	case 'btcolor':
																		if(loJs[i]==="000000")loJs[i] = rgb2hex($('.label-primary, .btn-primary').css('background-color'))
																		break;
																	case 'bocolor':
																		if(loJs[i]==="000000")loJs[i] = rgb2hex($('.border').css('border-color'))
																		break;
																	case 'hicolor':
																		if(loJs[i]==="000000")loJs[i] = rgb2hex($('.light').css('background-color'))
																		break;
																}
															}
															var aa = '<style class="colorLo">.border{border-color: #'+loJs.bocolor+'!important;} .primaryborder{border-color: #'+loJs.btcolor+'!important;} .label-primary, .btn-primary {background-color: #'+loJs.btcolor+'!important;} .light{background-color: #'+loJs.hicolor+'!important;} .bg{background-color: #'+loJs.bgcolor+';}</style>';
															if(stLoc && !c)aa = stLoc;
															localStorage.setItem('colorSt', aa);
															var loHtml = $('.colorLo')
															if(loHtml.length >0)loHtml.text($(aa).text());
															else $('head').append(aa);
														}else{
															$('.colorLo').remove();
															$('.bgcolor,.btcolor,.hicolor,.bocolor').val('000000');
															$('.bgcolor,.btcolor,.hicolor,.bocolor').css('background-color','#000000');
														}
													}
													getLoColor()
													$('.ssss').click(function(e){
														e.stopPropagation();
														$('.divColorLo').slideToggle();
