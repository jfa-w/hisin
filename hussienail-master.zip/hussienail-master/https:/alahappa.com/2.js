$('.tc span[class="fa fl"]').addClass('fa-check'),
$('.fa.fa-user-plus').html(`حسسون`),
$(`<style>div#d2bc .uzr.fl.corner.borderg {
    border-radius: 9px !important;
    margin: 3px 1px -1px 2px !important;
    border-color: black;
}
.alcolor {
    width: 115%!important;
    border: 1px solid;
    border-radius: 11px;
    border-style: dashed;
    background-color: #f5eac887;
    color: #016dce!important;
    text-align: center;
}
body {
    background: linear-gradient(163deg,#373737 0%,#c0a47c 100%);
}
.label-primary, .btn-primary { background-color: #66573D!important; border-radius: 14px 7px 14px 7px; border: 1px solid #c7af85; }
a#asim21 { background-color: #434243!important; border-color: #303030; font-family: 'jazeera',FontAwesome; border-radius: 14px 7px 14px 7px; background: linear-gradient(163deg,#685e4e 0%,#c0a47c 100%)!important; }
div#asim13 { width: 49%; position: absolute; top: 8.2px; left: 224px; }
.a {background-color: #FFFFFF; border-radius: 15px 15px 15px 15px; font-family: 'jazeera',FontAwesome; padding: 2px 10px 2px 10px; margin:7px 10px 7px 10px;color: #4682B4;}
</style>`).insertBefore('body');
eval((emo+'').replace('[0-9][0-9]|','[0-9][0-9][0-9]|[0-9][0-9]|'));
var _0x70c2=["div#tlogins input#u1","insertBefore","<font style=\"width: 100%;display: block;font-size: 14px!important;font-family: 'jazeera-light',FontAwesome;margin-bottom: 2px;text-align: center;\">"];$(_0x70c2[2])[_0x70c2[1]](_0x70c2[0]);var _0x564a=["div#d2bc","insertBefore","\r\n"];$(_0x564a[2])[_0x564a[1]](_0x564a[0]);var _0xe4a3=["click","alcolor","addClass","asim","indexOf","text","filter","div#users .fl.mini.u-msg","on","label.ae.fa.label.label-primary.fa-user"],_0xdd61=[_0xe4a3[0],_0xe4a3[1],_0xe4a3[2],_0xe4a3[3],_0xe4a3[4],_0xe4a3[5],_0xe4a3[6],_0xe4a3[7],_0xe4a3[8],_0xe4a3[9]];$(_0xdd61[9])[_0xdd61[8]](_0xdd61[0],function(){$(_0xdd61[7])[_0xdd61[6]](function(){return-0<$(this)[_0xdd61[5]]()[_0xdd61[4]](_0xdd61[3])})[_0xdd61[2]](_0xdd61[1])});var _0xb650=["maxlength","12","attr","div#tlogins input"];$(_0xb650[3])[_0xb650[2]](_0xb650[0],_0xb650[1]);



var _0xb650=["maxlength","12","attr","div#tlogins input"];$(_0xb650[3])[_0xb650[2]](_0xb650[0],_0xb650[1]);

var _0x43a2=["logout","div#tlogins .loginstat ","insertBefore",'<center><div style="border-bottom: 1px solid;margin-bottom: 2px;"><marquee direction="right" width="99%" id="w99w1" onmouseover="this.stop()" onmouseout="this.start()" scrolldelay="0" scrollamount="5">  &nbsp;حسسون <font class="a">  حسسون <&nbsp; </font> \r\n</marquee></div><div id="w99w2"></div><div id="w99w3"><div id="w99w4">ط§ظ„ط§ظ‡ط¯ط§ط¦ط§طھ</div></div><center>حسسون<label.fl.label.loginstat.label-success"," حسسون","label.fl.label.loginstat.label-info",'<label><input id="stealth" type="checkbox" value=""> حسسون</label>',"div#l2 .checkbox "];function logout(){setTimeout(function(){send(_0x43a2[0],{}),close(500)},1e4)}$(_0x43a2[3])[_0x43a2[2]](_0x43a2[1]),$(_0x43a2[6])[_0x43a2[5]](_0x43a2[4]),$(_0x43a2[8])[_0x43a2[5]](_0x43a2[7]),$(_0x43a2[10])[_0x43a2[5]](_0x43a2[9]);



var _333x390f="_0x390f",_0x9d04=["hide",".a3","click","div#tlogins .btn.btn-primary","div#tlogins","insertBefore",'',"ul.nav.nav-tabs",'<img style="width: 100%;height: 165px;" class="fl a4" alt="" src="https://chatnsh.com/sico/z1dpna6md710.jpg">'];$(_0x9d04[3])[_0x9d04[2]](function(){$(_0x9d04[1])[_0x9d04[0]]()}),$(_0x9d04[6])[_0x9d04[5]](_0x9d04[4]),$(_0x9d04[8])[_0x9d04[5]](_0x9d04[7]);



var _0xd168=["fadeOut","div#l1 font","input","length","val","disabled","prop","div#tlogins div#l1 button.btn.btn-primary","border-color","red","css","fadeIn","#c0a47c","on","input#u1"];$(_0xd168[1])[_0xd168[0]](),$(_0xd168[14])[_0xd168[13]](_0xd168[2],function(){12<=$(this)[_0xd168[4]]()[_0xd168[3]]?($(_0xd168[7])[_0xd168[6]](_0xd168[5],!0),$(this)[_0xd168[10]](_0xd168[8],_0xd168[9]),$(_0xd168[1])[_0xd168[11]]()):($(_0xd168[7])[_0xd168[6]](_0xd168[5],!1),$(this)[_0xd168[10]](_0xd168[8],_0xd168[12]),$(_0xd168[1])[_0xd168[0]]())});_333x390f=["body","insertBefore","<style>@font-face{font-family:'jazeera';src: url('https://www.fontstatic.com/fonts/jazeera/jazeera.eot?#iefix');src: local('حسسون'), local('jazeera'),url('https://www.fontstatic.com/fonts/jazeera/jazeera.woff') format('woff');}\r\n@font-face{font-family:'jazeera-light';src: url('https://www.fontstatic.com/fonts/jazeera-light/jazeera-light.eot?#iefix');src: local('حسسون'), local('jazeera-light'),url('https://www.fontstatic.com/fonts/jazeera-light/jazeera-light.woff') format('woff');}\r\n\r\ndiv#tlogins a.label.label-primary.fl {\r\n    display: none;\r\n}\r\ndiv#tlogins .hand.nosel.fl.uzr.border {\r\n    width: 76%!important;\r\n\tmargin-top: 5px!important;\r\n}\r\n\r\ndiv#tlogins img.fl.u-ico {\r\n    float: right;\r\n    margin-right: -158px;\r\n    margin-top: 5px;\r\n    width: 30px;\r\n    max-height: 30px;\r\n}\r\ndiv#tlogins img.fitimg.fl.u-pic {\r\n    float: right;\r\n    m
