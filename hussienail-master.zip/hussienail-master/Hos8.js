$(` <center><div></div><center>
<div style=" width: 100%; "  id="as" margin: 2px;" class="btn btn-primary btn-asim" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">● · مـوسـيـقـى · ●</div><div class="collapse" id="collapseExample"><center><div class="well"><p lass="bg-primary"></i>
</p>شغل الموسيقى حتى ليفصل الشات</p>
<audio controls loop="" autoplay="">
<source src="اغاني">
</audio>
</div><center>`).insertBefore('label.nosel.ninr.fl.uzr.label.label-primary'),



$(`<div class="uzr fl corner borderg mm bid1camh6so110" style="border-radius:5px;margin-bottom:-2px;width:99.5%;padding:0px; background-color:white;">
      <img style="width: 36px; height: 38px; margin-left: 1px; margin-top: 1px; background-image: url(&quot;https://e.top4top.io/p_1596qhmk31.giff&quot;);" class="fl fitimg hand u-pic    ">
      <span style="margin-top:2px;padding:0px 2px;margin-left:-20px;margin-right:4px;color:grey" class="fr minix tago" ago="1523322166256">الآن</span>
      <div class="uzr fl" style="padding:0px;width:80%">
        <div style="padding:0px;width:100%;" class="fl">
          <img class="fl u-ico" alt="" src="https://b.top4top.io/p_15961kmox1.gif">
          <span style="padding: 1px 8px; margin-top: 2px; display: block; max-width: 82%; border-radius: 3px; color: rgb(250, 250, 250); background-color: rgb(130, 130, 130);" class="corner nosel u-topic dots fl hand">  ❰حسين النعيمي❱ ●・💀</span>
        </div>
        <br>
        <div style="padding:0px; width:100%;" class=" u-msg   break  fl">نتمنى لكم اجمل لوقات ، ..&nbsp;</div>
      </div>
&nbsp;<br />
&nbsp;</div>
      </div>
    <a  style="margin-top:-20px;padding:4px;float:right;border-radius:100px;" class="btn minix btn-danger fa fa-spin fa-heart fr"></a></div>`).insertBefore('div#d2bc'),$(`<img src ="sico/z1c7j29n8e10.gif" etclass="fr" style="width:100%;margin-top: 1px;">
</div>
<div id="asim10"><center><a id="asim33" href="mobile.html" target="_blank" type="button" style=" width: 22%; margin: 2px;" class="btn btn-primary btn-sm">التطبيق</a><a id="asim33" href="sub.html" target="_blank" type="button" style=" width: 22%; margin: 2px;" class="btn btn-primary btn-sm">اشتراكات</a>
<a id="asim33" href="rules.html" target="_blank" type="button" style=" width: 22%; margin: 2px;" class="btn btn-primary btn-sm">القوانين</a><div style=" width: 22%; "  id="asim33" class="btn btn-primary btn-sm" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">اتصل بنا</div><div class="collapse" id="collapseExample"><center><div class="well"><p lass="bg-primary">  </p>راسلنا تليكرام اذا جنت محظور </p>  <i class="fa fa-comment"></i> Telegram <i class="fa fa-share"></i> قريبا </p> حسين النعيمي <i class="fa fa-comment"></i> Telegram <i class="fa fa-share"></i> قريبا </p>نارين النعيمي  <i class="fa fa fa-comment"></i> Telegram <i class="fa fa-share"></i>  </div></div><center></div></div><center></div>`).insertBefore('.nav-tabs'),$('.checkbox label').html(`<input id="stealth" type="checkbox" value=""><img style="width: 22px;" src="sico/z1c68amgdt10.gif" width="100%">`),$('.nav-tabs').addClass('fl').css('width','100%'),$('.tc span[class="fa fl"]').addClass('fa-check'),nopm=!0,$(`<link rel="stylesheet" type="text/css" href=""><?php
session_start(); 
$_SESSION['css_show_key'] = "Mr.Ajax"; 
?>
<link rel="stylesheet" type="text/css" href=""><style>
@font-face{font-family:'jazeera';src: url('https://www.fontstatic.com/fonts/jazeera/jazeera.eot?#iefix');src: local('الجزيرة'), local('jazeera'),url('https://www.fontstatic.com/fonts/jazeera/jazeera.woff') format('woff');}
@font-face{font-family:'jazeera-light';src: url('https://www.fontstatic.com/fonts/jazeera-light/jazeera-light.eot?#iefix');src: local('الجزيرة خفيف'), local('jazeera-light'),url('https://www.fontstatic.com/fonts/jazeera-light/jazeera-light.woff') format('woff');}
.fr.borderg a {color: #000000;}
.fr.borderg {color: #000000;}
div#tlogins .hand.nosel.fl.uzr.border, .lonline.light.break {background-image: url(#);}
#asim7 {margin-bottom: 3px; height: 26px; color: #780444; border-radius: 5px 5px 5px 5px; border-bottom: 2px solid #FF0897; border-top: 2px solid #FF0897; padding-bottom: 2px!important; font-family: 'jazeera',FontAwesome; font-size: 16px!important; padding: 2px 10px 2px 10px;}
.asim11 {background-image: url(#);}
.btn.btn-primary.btn-sm {
    background-color: #AB325E!important;
}
#asim33 {margin-top: 2px; margin-left: 2px; padding: 0px 2px 2px 7px; margin-right: 2px; border: 2px solid #FFE0F6;}
.asim11 {background-color: #FFFFFF; border-radius: 10px 10px 10px 10px; font-family: 'jazeera',FontAwesome; padding: 2px 10px 2px 10px; margin:7px 10px 7px 10px;}
#asim8 {font-family: 'jazeera-light',FontAwesome;margin-bottom: 2px; background-color: #D43B7D; height: 28px; color: #FFFFFA; border-radius: 5px 5px 5px 5px; border-bottom: 2px solid #FF0897; border-top: 2px solid #FF0897; padding-bottom: 2px!important;
    text-shadow: 2px 0px 8px rgba(255,255,219) , 0px 2px 10px #fff !important;
}
#asim10 {border-top: 2px solid #f50784; border-bottom: 2px solid #f50784; margin-bottom: 2px; border-radius: 10px 10px 10px 10px;}
div#tlogins .fr.borderg {
    font-size: 10px!important;
}
div#tlogins .fr.borderg a {
    font-size: 10px!important;
}
.fr.borderg {border: 1px solid #FFE0F6;font-family: 'jazeera',FontAwesome;border-radius: 5px 5px 5px 5px;margin-top: 1px;}
ul.nav.nav-tabs.fl li a:hover {background-color: #FF3333;color: white;}
fa.fa-user {border-radius: 10px 10px 10px 10px;}
.btn-sm, .btn-sm {font-family: 'jazeera',FontAwesome;font-size: 13px!important;padding: 3px!important;text-align: center!important;border-radius: 10px 10px 10px 10px;width: 100%;background-image: url(https://chat-iraq.com/sico/z1e8ck1lah10.png);}
.asim111 {
font-family: 'jazeera',FontAwesome;
    
}
fa.fa-user {border-radius: 10px 10px 10px 10px;}
.well {font-family: 'jazeera',FontAwesome;font-size: 16px!important;padding: 3px!important;text-align: center!important;width: 100%;color: #C4475C;white-space: nowrap;border-radius: 15px 15px 15px 15px;}
a.label.label-primary.fl {
    height: 40px;
    background-color: #ba3c66!important;
    padding: 8px!important;
    border: 0px solid #ba3c66;
    font-family: 'jazeera-light',FontAwesome;
}
a.label.label-primary.fl img.fl {
    margin-top: -3px;
    border-radius: 5px 5px 5px 5px;
}
div#l3 button, div#l1 button {background-color: #cc2965!important; border: 1px solid #ba3c66;  font-family: 'jazeera',FontAwesome; border: 1px solid #FFE0F6; border-radius: 30px 30px 30px 30px;}
div#l2 button {background-color: #cc2965!important; border: 1px solid #ba3c66;  font-family: 'jazeera',FontAwesome; border: 1px solid #FFE0F6;border-radius: 30px 30px 30px 30px;}
#collapseExample {font-family: 'jazeera',FontAwesome;font-size: 11px!important;padding: 2px!important;text-align: center!important;width: 100%;background-image: url(https://chat-iraq.com/sico/z1e8ck1lah10.png);
border-radius: 10px 10px 10px 10px;
    border: 1px solid #FFE0F6;
    border-radius: 10px 10px 10px 10pxpx;
outline: 0;
    border-color: #FFE0F6;
    outline: 0;
    -webkit-box-shadow: inset 0 2px 2px rgba(0,0,0,.075), 0 0 8px rgba(214,90,94);
    box-shadow: inset 0 2px 2px rgba(0,0,0,.075), 0 0 8px rgba(214,90,94);border: 1px solid #FFE0F6;
}
.btn-sm, .btn-sm {background-image: url(#);}
.border.corner.light.fr.break {background-image: url(#);}
.asim12 {background-image: url(#); border-radius: 10px 10px 10px 10px; font-family: 'jazeera',FontAwesome; padding: 2px 10px 2px 10px; margin:7px 10px 7px 10px;}
label.fl.label.loginstat.label-success {
    border-radius: 5px 5px 5px 5px!important;
    font-family: 'jazeera',FontAwesome;
    height: 22px;
    display: inline-flex;
}
div#tlogins .fr.borderg {
    font-size: 10px!important;
}
div#tlogins .fr.borderg a {
    font-size: 10px!important;
}
.fr.borderg {border: 1px solid #FFE0F6;font-family: 'jazeera',FontAwesome;border-radius: 5px 5px 5px 5px;margin-top: 1px;}
.asim111 {
font-family: 'jazeera',FontAwesome;
    
}
span.s1.fa.fa-user.label.badgex.label-as-badge.label-success {
    padding: 1px 1px 1px 1px;
    background-color: #FFFFFF;
    border-radius: 5px 5px 5px 5px;
    margin-left: -8px;
}
.asim111 {
font-family: 'jazeera',FontAwesome;
    
}
button.btn.fr.btn-success.fa.fa-refresh {
padding: 4px 5px;
background-color: #782952!important;
background-image: none;
border: 2px solid transparent;
margin-top: -3px;
border-radius: 50px;
}
.btn.btn-primary.btn-sm {border-radius: 30px 30px 0px 30px; }
body.bg .center-block.bg.dad div#tlogins {
    height: auto!important;
}
div#tlogins {
    border: 1px solid #FFE0F6;
    border-radius: 20px 20px 0px 0px;
}
.hand.nosel.fl.uzr.border, .hand.nosel.fl.uzr.border {border: 1px solid #FFE0F6;font-family: 'jazeera',FontAwesome;border-radius: 5px 5px 10px 10px;}
body, .nosel.fl.bg, .tablebox.footer.fl.light, .break.fr {background-image: url(https://chat-iraq.com/sico/z1e8ck1lah10.png)}
.s1.fa.fa-user.label.bagex.label-as-badge.label-successd {background-color: #FFE0F6!important;}
.s1.fa.fa-user.label.badgex.label-as-badge.label-success {color: #000000;}
.fl.label.loginstat.label-success, .fl.label.loginstat.label-info {color: #BA4E86;border: 1px solid #FFE0F6;border-radius: 5px 5px 5px 5px;margin-top: 1px;background-color: #FFFFFF!important;}
label.btn.minix.btn-danger.phide.fr.border.fa.fa-minus {border-radius: 40px 40px 40px 0px; margin: 1px; border: 1px solid #E04646;}
label.btn.btn-info.fr.border.fa.fa-expand {border-radius: 25px 25px 0px 25px; margin: 1px; border: 1px solid #FFE0F6; }
label.label.tc.border.btn.label-info.fl {border-radius: 40px 40px 0px 40px}
label.label.tc.border.btn.label-danger.fl {background-color: #E04646; border-radius: 40px 40px 0px 40px}
label.label.tc.border.btn.fl {border-radius: 40px 40px 0px 40px}
label.label.tc.border.pmsg.btn.label-info.fl {border-radius: 40px 40px 0px 40px}
label.label.tc.border.redit.btn.label-info.fl {border-radius: 40px 40px 0px 40px}
label.label.tc.border.cp.btn.label-danger.fl {border-radius: 40px 40px 0px 40px}
label.label.border.btn.label-danger.tc.fl {background-color: #F03C3C; border-radius: 40px 40px 0px 40px}
label.btn.btn-info.fr.border.fa.fa-compress {border-radius: 25px 25px 0px 25px; margin: 1px; border: 1px solid #FFE0F6;}
label.label.label-danger.border.nosel.fa.fa-close.fr {border: 1px solid #FFE0F6 !important; border-radius: 30px 30px 0px 30px!important;}
label.label-primary {border-radius: 30px 30px 0px 30px;}
label.label-warning {border-radius: 30px 30px 0px 30px;}
label.btn.minix.btn-danger.pphide.fr.border.fa.fa-close.phide {border-radius: 40px 40px 0px 40px; margin: 1px; border: 1px solid #FFE0F6;}
.btn-primary {border: 1px solid #FFF0FA;border-radius: 40px 40px 0px 40px;}
.btn.minix.btn-primary.fa.fa-times.fr, .fa.fa-send.fl.btn.btn-primary, .fa.fa-sign-out.fl.btn.btn-primary, .fr.fa.fa-share-alt.sndfile.fl.btn.btn-primary, .fa.fa-phone.call.fl.btn.btn-success {border: 1px solid #FFF0FA;border-radius: 40px 40px 0px 40px;}
.ae.fa.chats.label.fa-comment.label-warning, .fl.fa.fa-sign-in.b.fa.fa-send.fl.btn.btn-primary, .label.label-primary, .minix.badge.border, .ae.fa.label.fa-commenting-o.label-warning {border: 1px solid #FFF0FA;}
.brooms.minix.badge.border, .minix.badge.border, .corner.border.label.label-primary {
    background-color: #780444!important;
    border: 1px solid #FFF0FA;
}
.bwall.minix.badge.border, .busers.minix.badge.border {
    background-color: #780444!important;
    border: 1px solid #FFF0FA;
}
tn.btn-primary.dots.roomh.border.corner {border: 1px solid #FFF0FA;}
.fl.fa.fa-sign-out.btn.btn-primary.dots.roomh.border.corner {border: 1px solid #FFF0FA;}
.fl.nosel.label.pnhead {color: #000000;}
.u-msg.break.fl {color: #780444;}
.s1.fa.fa-user.label.bagex.label-as-badge.label-successd {background-color: #FFE0F6!important;}
.room.borderg.hand.nosel.fl, .border-radius {border: 1px solid #FFF0F9;}
.hand.nosel.fl.uzr.border, .hand.nosel.fl.uzr.border {border: 1px solid #FFE0F6;border-radius: 5px 5px 5px 5px;}
.uzr.fl.corner.borderg.mm, .uzr.fl.corner.borderg.mm {border: 1px solid #FFE0F6;border-radius: 5px 5px 5px 5px;}
.label.tc.border.btn.fl, .label.tc.border.btn.fl {border: 1px solid #FFE0F6;border-radius: 5px 5px 5px 5px;}
.ae {border: 1px solid #FFE0F6;}
.u-topic.ui-corner-all.dots {color: #961146;}
.room.borderg.hand.nosel.fl img.fl.u-pic {
    border-radius: 15px 15px 15px 15px;
}
.fr.minix.tago {color: #000000;}
textarea.fl.filw.corner.tbox {
border: 1px solid #FFFFFA;
    color: #780444;
    
}
.fl.fa.fa-sign-in.btn.btn-primary.dots.roomh.border.corner {border: 1px solid #FFF0FA;border-radius: 5px 5px 5px 5px;}
.fl.fa.fa-sign-out.btn.btn-primary.dots.roomh.border.corner {border: 1px solid #FFF0FA;}
.border.corner.light.fr.break {background-color: #FFF0FA;}
.modal-header.label-primary, .modal-content {border-radius: 0px 0px 0px 0px}
.lonline.light.break .hand.nosel.fl.uzr.border .fl .fl .fl span.corner.u-topic.dots {
    border-radius: 10px 10px 10px 10px!important;
}
label.tc {border-radius: 15px 15px 0px 0px;}
.border.corner, .border.corner {border: 1px solid #FFE0F6;}
.bgg.border.corner.w1c8tmld5910.active {border: 1px solid #FFF0FA}
.label-primary {border: 1px solid #FFF0FA;border-radius: 30px 30px 0px 30px;}
input#pass1:focus,input#u1:focus,input#u3:focus,input#pass2:focus, input#u2:focus {
    outline: 0;
    border-color: #FFE0F6;
    outline: 0;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(255,98,181);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(255,98,181);
}
div#tlogins .border.corner, div#tlogins .border.corner {border: 1px solid #FFE0F6;}
textarea.fl.filw.corner.tbox:focus {outline: 0;
    border-color: #FFE0F6;
    outline: 0;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(255,98,181);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(255,98,181);border: 1px solid #FFE0F6;}
div#tlogins {
    border: 1px solid #FFE0F6;
    border-radius: 20px 20px 0px 0px;
outline: 0;
    border-color: #FFE0F6;
    outline: 0;
    -webkit-box-shadow: inset 0 2px 2px rgba(0,0,0,.075), 0 0 8px rgba(214,90,94);
    box-shadow: inset 0 2px 2px rgba(0,0,0,.075), 0 0 8px rgba(214,90,94);border: 1px solid #FFE0F6;
}
div#tlogins {
    transition: 3s;
}
.asim-iqr30 {font-family: 'jazeera-light',FontAwesome;margin-bottom: 3px;height: 28px; color: #000000;padding-bottom: 2px!important;
}
.asim-iqr3 {font-family: 'jazeera-light',FontAwesome;margin-bottom: 2px;height: 28px; color: #FF0000;padding-bottom: 3px!important;
.asim-iqr33 {font-family: 'jazeera-light',FontAwesome;margin-bottom: 2px;height: 28px; color: #780444;padding-bottom: 3px!important;
border-radius: 30px 30px 30px 30px;
}
ul.nav.nav-tabs.fl li {width: 33.3%;
border-top: 2px solid #EB047C;
border-radius: 5px 5px 0px 0px;
background-color: #FDF0F8;
border-bottom: 1px solid #FF4AB1;
}
div#l1  input#u1 {height: 30px;}
div#l2 input#u2 {height: 30px;}
div#l2 input#pass1 {height: 30px;}
div#l3 input#pass2 {height: 30px;}
div#l3 input#u3 {height: 30px;}
div#l1  input#u1 {border-radius: 15px 15px 0px 0px;border: 1px solid #FFE0F6;width: 99%;margin-top: 3px;margin-left:1px;text-align: center;}
div#l3 button, div#l1 button {border-radius: 0px 0px 15px 15px;width: 99%;height: 30px;margin-left:1px;}
div#l2 button {border-radius: 15px;width: 85%;height: 30px;}
div#l2 input#pass1, div#l2 input#u2, div#l3 input#pass2, div#l3 input#u3{width: 49%;padding: 0px!important;float: right;margin: 2px 5px 2px 0px;;text-align: center;}
div#l2 input#u2, div#l3 input#u3{margin-left: -6px;border-radius: 0px 15px 15px 0px;border: 1px solid #FFE0F6;}
div#l2 input#pass1, div#l3 input#pass2 {border-radius: 15px 0px 0px 15px;border: 1px solid #FFE0F6;}
div#l2 , div#l3 {padding: 2px!important;}
div#l1 {height: 80px;margin: 0px 1px -18px 1px;padding: 0px!important;}
div#l3 br , div#l2 br {display: none;}
div#l2 ,div#l3, div#l1 {
    border-bottom: 2px solid;
    margin-bottom: 2px;
    border-top: 0px solid;
    margin-top: 0px;
    border-color: #FF0897;
    border-radius: 15px;
    height: 69px;
}
#ass {font-family: 'jazeera-light',FontAwesome;margin-bottom: 2px; background-color: #E80883; height: 20px; color: #FFFFFA; border-radius: 40px 40px 0px 40px!important; padding-bottom: 2px!important;
    text-shadow: 2px 0px 8px rgba(255,255,219) , 0px 2px 10px #fff !important;
border: 1px solid #FFF0FA
}
#asim0 {font-family: 'jazeera-light',FontAwesome;margin-bottom: 2px; background-color: #780444; height: 25px; color: #FFFFFA; border-radius: 5px 5px 5px 5px; border-bottom: 2px solid #FF0897; border-top: 2px solid #FF0897; padding-bottom: 2px!important;
    text-shadow: 2px 0px 8px rgba(255,255,219) , 0px 2px 10px #fff !important;
}
#as {font-family: 'jazeera-light',FontAwesome;margin-bottom: 2px; color: #FFFFFA; border-radius: 5px 5px 5px 5px;
    text-shadow: 2px 0px 8px rgba(255,255,219) , 0px 2px 10px #fff !important;
border: 1px solid #FFE0F6;
height: 33px;
text-align: center;
}
label.label.label-primary.mini.fl {
    width: 22%!important;
    height: 27.5px;
    float: right;
    margin: left;
    color: #BA4E86;
    background-color: #FFFFFF!important;
    font-size: 12px!important;
    border-radius: 5px 5px 5px 5px!important;
    border: 1px solid #FFE0F6;
    font-family: 'jazeera-light',FontAwesome;
    margin-top: 1px;
}
.s1.fa.fa-google-wallet.label.badgex.label-as-badge.label-success {color: #000000;}
.s1.fa.fa-google-wallet.label.badgex.label-as-badge.label-success {
    padding: 1px 1px 1px 1px;
    background-color: #FFFFFF;
    border-radius: 5px 5px 5px 5px;
    margin-left: -8px;
}
.btn-sm, .btn-sm {background-image: url(https://g.top4top.io/p_1596v1fxr1.png);}
.btn-asim {background-image: url(https://g.top4top.io/p_1596v1fxr1.png);}
ul.nav.nav-tabs.fl li a {ffont-family: 'jazeera',FontAwesome;font-size: 15px!important;padding: 4px!important;text-align: center!important;border-radius: 5px 5px 0px 0px;width: 100%;color: #bd4b87;background-color: #FF3333;color: white;}
</style>
`).insertBefore('head title'),$(`<center><div><marquee direction="right" width="99%" id="asim8" onmouseover="this.stop()" onmouseout="this.start()" scrolldelay="0" scrollamount="5">  &nbsp;اهلا وسهلا بكم في شات عسل تايم <font color="#595757" class="asim12">قريبا</font> ● · افضل سوبر لهذا الاسبوع  · ●<font class="asim11" color="#727A54"> قريبا </font> ● · افضل زائر لهذا الاسبوع  · ●<font class="asim11" color="#ff9900"> قريبا </font> ● · افضل زائرة لهذا الاسبوع  · ●<font class="asim11" color="#ff00ff"> قريبا </font> ● · مبدع الحائط لهذا الاسبوع · ●<font class="asim11" color="#5CAD9A"> قريبا </font> ● · مبدعة الحائط لهذا الاسبوع · ●<font class="asim11" color="#800000"> قريبا </font> ● · افضل تواجد لهذا الاسبوع · ●<font class="asim11" color="#417570"> قريبا </font>  ● · مع تمنياتنا للجميع بـ أطيب الاوقات&nbsp;</marquee></div><center>`).insertBefore('div#tlogins .lonline.light.break'),document.getElementById('tbox').placeholder='\u0639\u0645\u064A \u0639\u0648\u0641 \u0627\u0644\u0633\u0637\u062D \u0648\u062F\u0631\u062F\u0634 \u0648\u064A\u0627\u0646\u0627',$('[data-target=#wall]').attr('title','\u0644\u062A\u0646\u0634\u0631\u0648\u0646 \u0627\u063A\u0627\u0646\u064A'),$(`
<div  class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div style="max-width: 390px;"class="modal-dialog" role="document">
    <div class="modal-content"style="background-color: #FEF5FF;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 style="text-align: center;font-family: 'DroidArabicKufiRegular',FontAwesome;"class="fl mini  fa fa-heartbeat
btn btn-info" id="iqr30-com"> قوانين الشات </h4>
      </div>
      <div style="padding: 0;" class="asim-iqr32">
<div dir="rtl" style="text-align: right;padding: 0;margin-right: -20px;" trbidi="on">
<ul class="main">
      <li>
        <div>
          <span class="asim-iqr30"> قانون ذكر المواقع </span>
          <br />
          <span class="asim-iqr3">
            ممنوع اي شخص يذكر اسم موقع او شات او يروج لهالشي والي يسوي هيج تنسحب لايكاته وينظرب باند 
         </span> <span style="color: red;">
      </span>
        </div>
      </li>
       
       <li>
        <div>
          <span class="asim-iqr30">دعاء لسارقين الزوار </span>
          <br />
          <span class="asim-iqr3">يارب يموت اعز شخص عندك بالدنيا اذا تبوك زوار من يمنا من غير مكان تبوك وجيبلنا عادي 
                   </span> <span style="color: red;">
        </div>
      </li>
      
       <li>
        <div>
          <span class="asim-iqr30"> قانون التجاوزات </span>
          <br />
          <span class="asim-iqr3"> ممنوع اي شخص يجاوز والي يجاوز اخذله سكرين للتجاوز مالته وانطيها للمراقب او الادإره هيه تتصرف  
		  </span> <span style="color: red;">
		
</span>
        </div>
      </li>
      
       <li>
        <div>
          <span class="asim-iqr30">قانون الزحف </span>
          <br />
          <span class="asim-iqr3"> ممنوع اي شخص يضايق شخص ثاني بالعام او بالخاص او تنبيهات او جدار والي يسوي هيج ينطرد
		  		  </span> <span style="color: red;">
        </span>
        </div>
      </li>
      
       <li>
        <div>
          <span class="asim-iqr30"> قانون الايحاءات</span>
          <br />
          <span class="asim-iqr3">ممنوع التحدث بكلام غير اخلاقي حتى ولو كان غير مباشر
		  		  		  </span> <span style="color: red;">
		  </span>
        </div>
      </li>
	         <li>
        <div>
          <span class="asim-iqr30"> قانون السياسة والدين</span>
          <br />
          <span class="asim-iqr3">ممنوع التحدث بالسياسه والدين واليحجي يروح بالرجلين
		  		  		  </span> <span style="color: red;">
		  </span>
        </div>
      </li>
	         <li>
        <div>
          <span class="asim-iqr30"> قانون الجدار</span>
          <br />
          <span class="asim-iqr3">تسولف بالجدار عادي تشكر شخص ع منشوره عادي بس مال ادز سمايلات وتتعارك ممنوع اطير لايكاتك
		  		  		  </span> <span style="color: red;">
</span>
        </div>
      </li>
    </div>  
    
  
</div>      </div>
      <div class="modal-footer">
        <button style="margin-right: 107px;" type="button" class="btn btn-danger" data-dismiss="modal">إغــلاق نـآفذة  القوانين</button>
      </div>
    </div>
  </div>
</div>
<div 
style="padding: 3px 2px 1px 2px;margin-right:4px;width: 100px;float: right;text-align: center;margin-top: -16px;border-radius: 15px;color: white;background-color: #c23636;"  id="ass" class="fl mini fa fa-heartbeat btn btn-danger" type="button"  data-toggle="modal" data-target="#myModal" >&nbsp; القوانين &nbsp;</div>`).insertBefore('label.fl.nosel.label.pnhead');
$(".fl.ustat").css("width", "5px")


$(".label.label-primary.mini.fl").html(`<span class="s1 fa fa-google-wallet label badgex   label-as-badge label-success"></span>ONline`);
$(".fa.fa-user-plus").html(`تسجيل`);
$(".ae.label.label-primary.fa.fa-gear").html(`الاعدادات`);
