setTimeout (function (){   $("<div class='fr borderg' style='padding:2px;background-color:white;margin-right: 0;margin-top: 1px;position: absolute;right: 0;<a href='//a></div>").insertAfter($(".loginstat"));  },1000);
    $(`

<div class="rainbow"><img src="https://h.top4top.io/p_1596mp9ny1.jpg" class="fl" style="width:100%;margin-top: 1px;background-color: white;border-radius: 10px;"></div>




<a href="#" style="border-radius: 15px 0px;width:110px;margin:3px;" class="fl mini  fa fa-star-half-o btn btn-default">⠀الإشتراكات⠀</a>
<a href="#" style="border-radius: 15px 0px;width:110px;margin:3px;" class="fl mini fa fa-bell btn btn-default">⠀القوانيـن⠀</a>  
<a href="#" style="border-radius: 15px 0px;width:110px;margin:3px;" class="fl mini  fa fa-heartbeat btn btn-default">⠀التطبيـق⠀</a>  
`).insertBefore('.nav-tabs');


$(`<link rel="stylesheet" type="text/css" href="">
<link rel="stylesheet" href="https://rawcdn.githack.com/waleed-qaid/des/0beca86c9447a28d955cdb9276bf38dab0bb3228/abo-arish.css">
<style>
.fitimg.fl.u-pic  {box-shadow: 0 1px 1px -1px  rgb(0, 95, 105), 0 0 6px rgb(0, 95, 105);border-radius: 4px 4px 4px 4px;;}
textarea.fl.filw.corner.tbox {border-radius: 10px;padding-left: 5px;border: 2px solid #005F69;margin-top: 2px;}
.label.tc.border.btn.fl, .label.tc.border.btn.fl {border: 2px solid #adadad;font-family: 'jazeera',FontAwesome;border-radius: 24px 24px 24px 24px;}

<style>
label.ae.fa.chats.label.fa-comment.label-warning {background-color: #016B16;}
label.ae.fa.label.fa-commenting-o.label-warning {background-color: #016B16;}
ul.nav.nav-tabs.fl li a {background-color: #FFFFFF!important;}
.label-danger, .label-success {background-color: #016B16;}
.fr.borderg, .fr.borderg a { border-radius: 3px!important;margin-right: 0!important;background-color: #016B16!important;border: 0 solid #FFFFFF;color: #FFFFFF; }
#des1 { margin-bottom: 2px;background-color: #359917;color: #CFCFCF;border-bottom: 1px solid #359917;border-top: 1px solid #8C0059;padding-bottom: 3px; }
</style>`).insertBefore('body');
$("[data-target=#wall]").attr('title','  ♥️ مســـاحه حــره لأبــدآعاتكــم ♥️           ')
$('.nav-tabs').addClass('fl').css('width','100%');
$(".fa-gear").text("الاعدادات ").css("width","")

  $("marquee").text(" أهلا وسهلا بكم في :شـات المحبه » تستطيع الدخول من جوالك او اللاب توب او الاي باد ومن جميع الاجهزة اللوحيه نتمنى لكم قضاء اجمل الاوقات معنـــا - الادارة");

$('.break.light').css({"background-image":"url(https://c.top4top.io/p_1593s47ae1.gif)"});


$(`<div style=" padding: 3px;margin: 2px; border: 1px solid #D6E3E3;height: 29px;width: 106px;" class="btn " type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">الادارة</div>
<div class="collapse" id="collapseExample"><div style="text-align: center;font-family: 'jazeera';color: #C91212;" class="well">
<p class="bg-primary">｢ فيصل ｣｢<p class="bg-primary">｢للشكاوي والاقتراحات ｣｢</p><p class="bg-primary">｢النايفه  ｣｢</p>｢ حسين النعيمي ｣｢</div> 



</div>`).insertBefore('a.fl.fa.fa-comment.btn.ui-corner-all.ui-shadow.ui-btn.ui-btn-inline.upm.borderg');

$(`<img tabindex="0" class="al120 fl " style="margin-left: -4px; padding:5px; width:40px;margin-top: -4px;" src="https://i.top4top.io/p_1598k5jsn1.gif" data-original-title="" title=""><img tabindex="https://c.top4top.io/p_1593s4" class="al121 fl " style="padding:5px;width: 33px;margin-top: 0px;margin-left: -6px;" src="" data-original-title="" title="">`).insertAfter('img.fl.nosel.emobox');
$(".al120").click(function(){
alert("عذرا لا تملك الصلاحية للدخول الى منتدى النايفه) ");
});
$('.break.light').css({"background-image":"url(صوره)"});



$("div#tlogins button.btn.btn-primary").click(function(){
var myVar = setInterval(function(){ var usmsgw = $(".pmsgc").length;if(usmsgw > 0){
   $(`
    <div class="uzr fl corner borderg mm" style="border-radius:5px;margin-bottom:-2px;width:99.5%;padding:0px; background-color:white;">
      <img style="width: 36px; height: 38px; margin-left: 1px; margin-top: 1px; background-image: url();" class="fl fitimg hand u-pic    ">
      <div class="uzr fl" style="padding:0px;width:80%">
        <div style="padding:0px;width:100%;" class="fl">
          <img class="fl u-ico" alt="" src="https://g.top4top.io/p_1593k5f4d1.png">
          <span style="padding: 1px 8px; margin-top: 2px; display: block; max-width: 82%; border-radius: 3px; color: E00000(199, 103, 48);" class="corner nosel u-topic dots fl hand">شات النايفه الرسمي</span>
        </div>
        <br>
        <div style="padding: 0px; width: 100%; color: rgb(60, 0, 255);" class=" u-msg   break  fl">
        <div style="padding: 0px;width: 100%;color: rgb(60, 0, 255);text-align: left;display: block;margin-top: -17px;" class=" u-msg   break  fl"> مرحباً بك 👋👋👋👋 <h1 style="display: inline-block;color: red;">`+ getuser(myid).topic+ `</h1> نقدّر تواجدك معنا في شات النايفه  ونتمنى لك يوماً سعيداً إن شاء الله </div>
      </div>
    </div></div>
`).appendTo('div#d2')
clearInterval(myVar);

}else{console.log(usmsgw)} }, 2000);
})

