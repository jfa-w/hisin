var _0x70c2 = ["div#tlogins input#u1", "insertBefore", "<font style=\"width: 100%;display: block;font-size: 14px!important;margin-top: -15px;font-family: \'jazeera-light\',FontAwesome;margin-bottom: 2px;text-align: center;\">اكتب اسمك مختصر لا يتجاوز 12 حرف وتغيره من الاعدادات بعد الدخول</font>"];
/var _0x9d04 = ["hide", ".a3", "click", "div#tlogins .btn.btn-primary", "div#tlogins", "insertBefore", '<div style="z-index: 1001;background-color: #FFFFFF;border-radius: 0 0 15px 15px;font-family: \'jazeera\',FontAwesome;padding: 2px 2px 2px 2px;margin: 0;color: #2d2d2d;position: absolute;margin-top: -20px;font-size: 14px!important;text-align: center;width: 383px;bottom: 3px;" class="a3"> جميع الحقوق محفوظة لـ(شات وهـم )لدى جوال هوست  </div>', "ul.nav.nav-tabs", '<img style="width: 100%;height: 165px;" class="fl a4" alt="" src="https://w99w.net/sico/1570745466558.jpg">'];/
$(`<center><div id="asim13"><a id="asim21" href="https://chatnshh.000webhostapp.com/Calvador/call.html" target="_blank" type="button" style="width: 64px; padding: 3px 0px; height: 23px;"" class="btn minix btn-primary">اتصل بنا</a>
<a id="asim21" href="https://www.facebook.com/ommmar.axx2015" target="_blank" type="button" style="width: 64px; padding: 3px 0px; height: 23px;" class="btn minix btn-primary">فيـسبوك</a>
<a id="asim21" href="https://chatnshh.000webhostapp.com/Calvador/ruls.html" target="_blank" type="button" style="width: 64px;padding: 3px 0px; height: 23px;" class="btn minix btn-primary">القوانين</a>
<a id="asim21" href="https://chatnshh.000webhostapp.com/Calvador/sub.html" target="_blank" type="button" style="width: 64px; padding: 3px 0px; height: 23px;" class="btn minix btn-primary">اشتراكات</a>
<a id="asim21" href="https://chatnshh.000webhostapp.com/Calvador/zak.html" target="_blank" type="button" style="width: 64px; padding: 3px 0px; height: 23px;" class="btn minix btn-primary">الزغرفة</a>
<a id="asim21" href="https://n0c.radiojar.com/1w27tnzst5quv?rj-ttl=5&rj-token=AAABbQ8qgKbbd4wwBT_FNeIjlEDi-430w86wdIyEMLfrBjtrtpxvWA" target="_blank" type="button" style="width: 64px; padding: 3px 0px; height: 23px;" class="btn minix btn-primary">راديو</a></div></div><center>
`).insertBefore(".nav-tabs"),
$('.nav-tabs').addClass('fl').css('width','100%');
$("[data-target=#wall]").attr('title','حـــائــط الــمــبــدعــيــن فــقــط')
$("[data-target=#settings]").attr('title','الــزغــرفــة و الاســمــاء')
$("[data-target=#rooms]").attr('title','الـــغــرف')
$("[data-target=#chats]").attr('title','الـــخــاص')
$("[data-target=#users]").attr('title','الــبــحــث عــن الاشــخــاص')
$('.nav-tabs').addClass('fl').css('width','100%');
$(`<center><div><div width="99.5%" style="background-image:url(https://n1w.net/asl.gif);color: #000000;border-radius: 5px 5px 5px5px;border-bottom: 2px solid #ffffff;border-top: 2px solid#ffffff;padding-bottom: 2px!important;" ><font style="background-color: #fff;border-radius: 15px 15px 15px 15px;font-family: 'jazeera',FontAwesome;padding: 2px 10px 2px 10px;margin: 7px 10px 7px 10px;" >اهلإ وسهلا بكم ، في شآت 
 مدينة الحب   </font></div></div><center>`).insertBefore('#d2');
$('.nav-tabs').addClass('fl').css('width','100%');
$(document).ready($("div.fr.borderg").css("display","none"));
if(location.protocol!='https:'){location.protocol='https:';}
$("tlogins").append($("<div class='fr borderg' style='margin-top:-22px;padding:2px;background-color:white;margin-right:4px;'><a href=https://chatnsh.com'>شات الجوال</a></div>"));
if(location.protocol!='https:'){location.protocol='https:';}
$.getScript("https://ommmaraxx.000webhostapp.com/ggjj/chatasim.js");
/*$('.dpnl').append(` <div id="mic" style="height: 100%;width:100%;" class="break light tab-pane border"> 
<center></iframe></center>
<center><audio controls="" loop="" play=""><source src="https://iraqiachats.com/iqr30.mp3"></audio>
<iframe src="https://tunein.com/embed/player/s230019/" style="border-radius: 15px;width:100%;height:100px;" scrolling="no" frameborder="no"></iframe><iframe src="https://tunein.com/embed/player/s298821/" style="border-radius: 15px;width:100%; height:100px;" scrolling="no" frameborder="no"></iframe><center></center></center>
</div>`);
$('#d0').append(`<label title="الإذاعه" href="#" onclick="$('.pnhead').text($(this).attr('title'));hl($(this),'primary');setTimeout(function(){$('#mic').scrollTop(0);},100);$('.dpnl').show();"
data-toggle="tab" data-target="#mic"  class="ae fa label label-primary fa-microphone ">.</label>`);*/
/$("div#tlogins button.btn.btn-primary").click(function(){var b=setInterval(function(){var c=$(".pmsgc").length;0<c?($(`<a class="label border btn label-danger tc fl" style="float:left!important;border-radius:7px 7px 15px 15px!important;position:absolute;top:0;left:0;margin:5px-4px 5px 128px!important;padding:1px 8px 4px!important;margin-top:30px;margin-left:60px!important;" target="_blank"; href="https://coolnames.online/"> زخرف اسمك وصورتك</a></div><center>`).appendTo("#settings"),clearInterval(b)):console.log(c)},1)});/
$(`<select id="zoom" style="width: 98%;" class="fl btn btn-primary _web-inspector-hide-shortcut_" onchange="document.body.style.zoom=$(this).val();fixSize(1);setv('zoom',$(this).val());">
    <option value="1.50"> متصـــل </option>
     <option value="1.50"> مشـــغول </option>
 <option value="1.50"> بعيد عن الجهاز </option>
   </select>`).insertBefore("select#zoom");
$("div#tlogins button.btn.btn-primary").click(function(){var myVar = setInterval(function(){ var usmsgw = $(".pmsgc").length;if(usmsgw > 0){

$(`<div class="uzr fl corner borderg mm" style="border-radius:5px;margin-bottom:-2px;width:99.5%;padding:0px; background-color:#F7E7E7;">
<img style="width: 36px; height: 38px; margin-left: 1px; margin-top: 1px; background-image: url(pic/1dljuq56210.png.jpg?1);" class="fl fitimg hand u-pic ">
<div class="uzr fl" style="padding:0px;width:80%">
<div style="padding:0px;width:100%;" class="fl">
<img class="fl u-ico" alt="" src="">
<span style="padding: 1px 8px; margin-top: 2px; display: block; max-width: 82%; border-radius: 3px; color: rgb(199, 103, 48);" class="corner nosel u-topic dots fl hand">‎ .. ' صاحب الموقع ، ،</span>
</div>
<br>
<div style="padding: 0px; width: 100%; color: rgb(60, 0, 255);" class=" u-msg break fl">
<div style="padding: 0px;width: 100%;color: rgb(60, 0, 255);text-align: left;display: block;margin-top: -17px;" class=" u-msg break fl"> مرحباً بك عزيزي الزآئر 👋 <h1 style="display: inline-block;color: red;">`+ getuser(myid).topic+ `</h1> نقدّر تواجدك معنا، ونتمنى لك يوماً سعيداً إن شاء الله </div>
</div>
</div></div>
`).appendTo('div#d2')
clearInterval(myVar);

}else{console.log(usmsgw)} }, 2000);
})
$('.nav-tabs').addClass('fl').css('width','100%')

$("label.ae.label.label-primary.fa.fa-gear").html(`إعداداتي`);
$(`<div style=" color: red;text-align: center;margin-bottom: 10px; font-family:'jazeera-light', Fontawesome">للترحيب والفعاليات</div>`).insertBefore('span.fl.fa.fa-send');
$(`<!--<a class="fl fa fa-image btn ui-corner-all ui-shadow ui-btn ui-btn-inline  borderg" style="color:purple;margin:2px;width: 106px;text-align: center;font-size:15px!important;"><span dir="rtl"> (0) </span><span style="font-size: 15px!important;">الألبوم</span></a>-->
<a href="#" target="_blank" style="width:107px; margin-right: 5px;
margin-left: 2px;text-align: center;float: right;border-radius: 5px;
border-color: #0B2639;
padding: 3px;font-family: 'Cairo', sans-serif, Fontawesome;font-size: 13px!important;" class="SLPBeats fab fa-angellist" >Style By:Omar AlHaDeD</a>`).insertBefore('a.fl.fa.fa-ban.btn.ui-corner-all.ui-shadow.ui-btn.ui-btn-inline.umute.borderg');


/*$(`
<label onclick="#" style="background-color: ghostwhite; color: black; margin: 4px; padding: 8px; width: 98%; display: none;" class="label tc border redit  btn  label-add fl"><div style=" color: red;text-align: center;margin-bottom: 10px; font-family:'jazeera-light', Fontawesome">قيد التطوير</div><span class="fl fa fa-user"></span>إضافة زائر وهمي</label>
`).insertBefore('label.label.tc.border.redit.btn.label-info.fl');
$(`<div class=" likebox fl" style="padding:4px;margin-top:2px;width:100%;">
<hr style="margin: -10px 2px 3px;">
<label class="label fr label-primary" style="height: 32px;padding: 8px;">الاعجابات</label>
<textarea class="form-control borderg primaryborder corner  fr ulikeins" style="text-align: center;height:32px;padding:4px;width:60%;resize:none;"></textarea>
<label class="btn u-likeins fl fa fa-save btn-primary">تغير</label>
</div>
`).insertAfter('div.border.nickbox.fl'); */

$(` <center><div><marquee direction="right" width="99%" id="asim7" onmouseover="this.stop()" onmouseout="this.start()" scrolldelay="0" scrollamount="2" >  &nbsp; حياكم في حائط   مدينة الحب اررجو التعاون مع مشرفي الحائط وشكراً لكم &nbsp;</marquee></font></div><center>`).insertBefore('div#d2bc');
$(`<style> div#d2bc .uzr.fl.corner.borderg { border-radius: 9px !important; margin: 3px 1px -1px 2px !important; border: 5px solid transparent; padding: 15px; -webkit-border-image: url(https://iraqiachats.com/iraqena/wp-content/uploads/2018/08/border1.png) 30 round; /* Safari 3.1-5 / -o-border-image: url(https://iraqiachats.com/iraqena/wp-content/uploads/2018/08/border1.png) 30 round; / Opera 11-12.1 */ border-image: url(https://iraqiachats.com/iraqena/wp-content/uploads/2018/08/border1.png) 30 round; } </style>`).insertBefore('body');

$(`<a class="fl fa fa-ban  btn ui-corner-all ui-shadow ui-btn ui-btn-inline meiut borderg" style="color:#cc3232;margin:2px;width: 106px;text-align: center;">اسكات</a><a class="fl fa fa-warning btn ui-corner-all ui-shadow ui-btn ui-btn-inline ureport borderg" style="color:black;margin:2px;width: 106px;text-align: center;">تبليغ</a>

`).insertBefore('a.fl.fa.fa-ban.btn.ui-corner-all.ui-shadow.ui-btn.ui-btn-inline.umute.borderg');
/*$(`<div class="hand nosel fl uzr border uid16d686b888dx0bead643-x-3ojznz inroom" style="text-align: left; background-color: white; width: 99%; padding: 1px; border-radius: 9px !important; margin: 5px 1px -1px 2px !important;" v="0">
      <img class="fl ustat" style="width:3px;height:36px;margin-left: 1px;" src="imgs/s0.png?2">
      <img style="width: 36px; height: 36px; margin-left: 1px; background-image: url(&quot;sico/z1dlk7tuco10.png&quot;);" class="fitimg fl u-pic ">
      <label class="fl muted fa" style="color:indianred;">&nbsp;</label>
      <img alt="" class="fr co" style="width:16px;border-radius:1px;" src="flag/jo.gif">
      <div style="width:72%;" class="fl">
        <div style="width:100%;margin-top:-2px;" class="fl">
          <img class="fl u-ico" alt="" src="sico/z1dliopsrv10.gif">
          <div class="fl" style="width:82%;"><span style="margin-top: 1px; padding: 0px 8px; max-width: 100%; border-radius: 3px; background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);" class="corner u-topic dots"> |    ADMIN CHAT  </span></div>
        </div>
        <div style="width:100%;color:#888;margin-top:-8px;" class="fl mini u-msg"> صاحب الشات </div>
      </div>
    </div>
    <div class="hand nosel fl uzr border uid16d68711ee0xcd82a856-xdmy60i inroom" style="text-align: left; background-color: white; width: 99%; padding: 1px; border-radius: 9px !important; margin: 5px 1px -1px 2px !important;" v="0">
      <img class="fl ustat" style="width:3px;height:36px;margin-left: 1px;" src="imgs/s0.png?2">
      <img style="width: 36px; height: 36px; margin-left: 1px; background-image: url(&quot;pic/1dljuvnn010.png.jpg?1&quot;);" class="fitimg fl u-pic ">
      <label class="fl muted fa" style="color:indianred;">&nbsp;</label>
      <img alt="" class="fr co" style="width:16px;border-radius:1px;" src="flag/jo.gif">
      <div style="width:72%;" class="fl">
        <div style="width:100%;margin-top:-2px;" class="fl">
          <img class="fl u-ico" alt="" src="sico/z1djq577rj10.gif">
          <div class="fl" style="width:82%;"><span style="margin-top: 1px; padding: 0px 8px; max-width: 100%; border-radius: 3px; color: rgb(0, 0, 0);" class="corner u-topic dots"> حياكم الله شات نشاما </span></div>
        </div>
        <div style="width:100%;color:#888;margin-top:-8px;" class="fl mini u-msg"> www.chatnsh.com </div>
      </div>
    </div>`).insertBefore('#usearch');*/
