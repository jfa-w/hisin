$(`<a id="تطوير-وتكويد-فهد-الشمري" href=""><i class="fa fa-refresh fa-spin fa-3x fa-fw" aria-hidden="true"></i></a><img id="لاتسرق-التصميم-ياتيس"src="https://mrkzgulfup.com/uploads/159699615598591.gif
"style="width:100%"><a id="تطوير-مطنوخ-ششمر"target="_blank"type="a"rel="nofollow"title=""href="http://www.dookmobile.com/"class="label-primary">برمجه حسين النعيمي </a></div></div><center>`).insertBefore(".nav-tabs"),$(".nav-tabs").addClass("fl").css("width","100%"),
$(`<center><div id="fahd99">
<a id="فهد"rel="dofollow" title="القوانين" href=""style="border-radius: 0 4px 0 0; border-right: 2px solid#f7d322;"class="fl mini  fa fa-bullhorn btn btn-primary" target="_blank"></a>
<a id="فهد"rel="dofollow" title="الاشتراكات" href=""style="border-right: 1px solid#fff;"class="fl mini  fa fa-star-half-o btn btn-primary" target="_blank"></a>
<a id="فهد"rel="dofollow" title="راديو" href=""style="border-right: 1px solid#fff;"class="fl mini  fa fa-volume-up btn btn-primary" target="_blank"></a>
<a id="فهد"rel="dofollow" title="زخرفة اسماء" href=""style="border-right: 1px solid#fff;"class="fl mini  fa fa-fire btn btn-primary" target="_blank"></a>
<a id="فهد"rel="dofollow" title="اتصل بنا" href=""style="border-right: 1px solid#fff;"class="fl mini fa fa-paper-plane btn btn-primary" target="_blank"></a>
<a id="فهد"rel="dofollow" title="قوانين السوابر" href=""style="border-right: 1px solid#fff;"class="fl mini fa fa-exclamation-triangle btn btn-primary" target="_blank"></a>
<a id="فهد"rel="dofollow" title="تطبيق الشات" href=""style="border-right: 1px solid#fff;"class="fl mini fa fa-android btn btn-primary" target="_blank"></a>
<a id="فهد"rel="dofollow" title="اختصارات الشات" href=""style="border-radius: 6px 0 0 0; border-left: 3px solid#f7d322; border-right: 1px solid#ffffff;"class="fl mini fa fa-tencent-weibo btn btn-primary" target="_blank"></a>
</div></div><center>
<center><div><marquee direction="right" id="oa43" onmouseover="this.stop()" onmouseout="this.start()" scrolldelay="0" scrollamount="3"> 

&nbsp;أهلا وسهلا بكم في شات <font color="#595757" class="فهد2">  اوتـار بغداد </font> ● · ‫أفضل سوبر لهذا الأسبوع · ● <font class="فهد2" color="#727A54">&nbsp; قريـــبا &nbsp;</font> ● · ‫أفضل زائر لهذا الأسبوع · ● <font class="فهد2" color="#ff9900">&nbsp;قريـــبا &nbsp;</font> ● · ‫أفضل زائرة لهذا الأسبوع · ● <font class="فهد2" color="#ff00ff">&nbsp; قريـــبا &nbsp;</font> ● · مبدع الحائط لهذا الأسبوع · ● <font class="فهد2" color="#5CAD9A">&nbsp; قريـــبا   &nbsp;</font> ● · مبدعة الحائط لهذا الأسبوع · ● <font class="فهد2" color="#800000">&nbsp; قريـــبا &nbsp;</font> ● · ‫أفضل تواجد لهذا الأسبوع · ● <font class="فهد2" color="#417570">&nbsp; قريـــبا &nbsp;</font> ● · مع تمنياتنا للجميع بـ أطيب الاوقات&nbsp;

</marquee></div><center>`
).insertBefore('div#tlogins .lonline.light.break');


$(`<style>
@font-face{font-family:jazeera;src:url(https://www.fontstatic.com/fonts/jazeera/jazeera.eot?#iefix);src:local(الجزيرة),local(jazeera),url(https://www.fontstatic.com/fonts/jazeera/jazeera.woff) format("woff")}
@font-face{font-family:jazeera-light;src:url(https://www.fontstatic.com/fonts/jazeera-light/jazeera-light.eot?#iefix);src:local( الجزيرة خفيف ),local(jazeera-light),url(https://www.fontstatic.com/fonts/jazeera-light/jazeera-light.woff) format("woff")}
.tcat a:link,.tcat_alink{color:#FFF;text-decoration:none;font-family:jazeera,FontAwesome}
t

.fa-remove:before,.fa-close:before,.fa-times:before{/* color:#ffffff;*/}
.fa-save:before.fa-remove:before,.fa-close:before,.fa-times:before{display:none}
a.btn.minix.fa.fa-times.fr{color:#0a7eb7!important;/* border-radius:4px;*/
  
/* padding:1px 4px 2px 5px;*/
  
/* margin-top:6px;*/
  
/* background-repeat:repeat-x;*/
  
/* border-color:#fff!important;*/
  
/* background-image:linear-gradient(to bottom,#f8f9fa 0,#dee2e6 100%)!important;*/
  
/* margin-left:1px;*/
  
/* width:13px;*/
  
/* margin-right:2px;*/}
span.minix.badge.border,span.bwall.minix.badge.border,span.brooms.minix.badge.border{display:none!important}
span.busers.minix.badge.border{display:inline!important}
span.bwall.minix.badge.border,span.brooms.minix.badge.border{display:none!important}
ul.nav.nav-tabs.fl li a:hover{background-color:#43a2a1;color:#fff}
ul.nav.nav-tabs.fl li .fa-user-plus:before{color:red;-webkit-animation:mymove .5s infinite;animation:mymove .5s infinite}
@-webkit-keyframes mymove{from{color:red}to{color:#FFF}}
@keyframes mymove{from{color:red}to{color:#FFF}}
a#تطوير-وتكويد-فهد-الشمري{color:#fff!important;position:absolute;right:1px;right:-14px;border:1px solid #ffffff!important;border-radius:100px 50px 30px 20px;width:50px;/* margin:160px 0 0 160px;*/
    
/* padding:0;*/
    height:18px;/* position:absolute;*/
    
/* border-color:#0035b5;*/
    
/* background-image:linear-gradient(to bottom,#0038b8 0,#0034ae 100%);*/
    background-color:#4971cf!important;/* border-left:10px #ffffff solid!important;*/
    
/* border-right:10px #ffffff solid!important;*/
    
/* border-left-style:double!important;*/
    
/* border-right-style:double!important;*/
    
/* -webkit-writing-mode:vertical-rl;*/
    1px 6px 1pxFONT-:;WEIGHT:100;/* padding:1px 6px 1px 100px!important;*/
    
/* background-image:linear-gradient(90deg,#0041cd 0,#ffffff 10%,#a0b6ea 51%,#b04d21 89%,#0061f7 100%);*/
    
/* background-image:linear-gradient(90deg,#0041cd 0,#1262d8 10%,#9dc0f3 51%,#4b6a8c 89%,#cc4605 100%);*/
    
/* background-image:linear-gradient(90deg,#0661e6 0,#0035b5 10%,#da992b 51%,#4b6a8c 89%,#4b6a8c 100%);*/
    
/* position:absolute;*/
    top:154px;/* left:-80px;*/
    
/* margin-top:6px!important;*/
    font-size:14px!important;/* margin-left:-14px!important;*/
    
/* padding:1px 6px 1px 75px!important;*/
    
/* border-right:7px #ffffff solid;*/
    
/* border-right-style:double;*/}
.fl.fa.fa-sign-in.btn.btn-primary.dots.roomh.border.corner{background-color:#039be5!important;padding:1px 4px!important;pointer-events:none}
.ae.label.label-primary.fa.fa-gear{padding:7px 5px 5px 13px;border-radius:0;margin-left:-3px!important}
.ae.fa.label.fa-commenting-o.label-primary{padding:7px 5px 5px 13px;margin-left:-4px!important;border-radius:0}
.ae.fa.label.label-primary.fa-users{padding:7px 5px 5px 13px;border-radius:0;margin-left:-3px!important}
.ae.fa.chats.label.fa-comment.label-primary{padding:7px 13px 5px;margin-left:-7px!important;border-radius:0}
.ae.fa.label.fa-commenting-o.label-warning{padding:7px 0 5px 9px;margin-left:-4px!important;border-radius:0}
.ae.fa.chats.label.fa-comment.label-warning{padding:7px 13px 5px;margin-left:-7px!important;border-radius:0}
.bgg.border.corner{border-bottom-right-radius:0!important}
label.fl.nosel.label.pnhead{background-color:#008e91}
iframe#فهدد-الشششمري{height:118px;float:left;border-bottom:3px solid #e5032f;background-color:#fff;margin-top:-6px;background-image:url();background-size:contain}
div#fahd99{text-align:center;border-radius:0 0 7px 7px;width:63%;position:absolute;top:172.9px;right:0;/* margin-left:33px;*/}
a#تطوير-فهد-الشمري{font-size:14px!important;width:25%!important;border:1px solid #f0ad4e;margin-right:5px;float:right;margin-top:-2px;padding:1px!important;height:24px!important;color:#fff!important;background-color:#43a2a1!important;margin-left:-8px}
a#مطنوخ-شمر{font-size:14px!important;width:25%!important;border:1px solid #f0ad4e;margin-right:5px;float:right;margin-top:-3px;padding:1px!important;height:23px!important;color:#fff!important;background-color:#43a2a1!important;margin-left:-8px}
.badge{display:inline!important;background-color:#7770;border-radius:33%;border:#1f95a208 solid 1px!important;margin-left:-5px;vertical-align:top}
div#menu-l{height:55px;width:307px;float:left;position:absolute;top:-11px;right:-7px}
.ae{border:1px solid #afabab}
.primaryborder{border-color:#008E91!important;border-radius:0!important}
button.fa.fa-sign-out.fl.btn.btn-primary{margin-top:0!important}
span.corner.fa.fa-user.label.label-primary.fr.uc{display:inline!important}
button.fa.fa-send.fl.btn.btn-primary{margin-top:0!important}
button.fa.fa-send.sndpm.fl.btn.btn-primary{margin-top:0!important}
.btn-primary:hover{border-left:1px solid #5290ac;border-top:1px solid #5290ac;border-right:1px solid #376b87;border-bottom:1px solid #376b87}
.fr.rating-box{border-left:8px #f00 solid;border-left-style:double;border-right:8px #f00 solid;border-right-style:double}
.fa-user-times{margin:0!important;background-color:#FFF;top:58px!important;transform:rotate(-90deg);width:123px!important;position:absolute;left:-41px}
.btn.hand.borderg.corner{width:32px;height:33px}
.ukick{margin:0!important;width:60px!important;background-color:#FFF!important;margin-top:14px!important;margin-left:-60px!important;position:absolute;top:1px}
.uban{margin:0!important;width:60px!important;background-color:#FFF;margin-top:73px!important;margin-left:-61px!important;position:absolute;top:1px}
.emoi{width:auto;max-width:-webkit-fill-available}
.uzr.fl.corner.borderg.hmsg.mm{background-color:#f0fffb!important}
.bgg.border.corner{right:1px}
img.fl.emobc{margin-top:-3px!important}
.callnot{position:absolute!important;top:1px!important;margin-left:0!important;left:1px}
.popover.right{max-width:initial;overflow:auto;width:auto;margin-left:-109px;height:369px}
.popover.fade.top.in{position:absolute;max-width:250px!important;max-height:200px;overflow:auto}
button.fa.fa-phone.call.fl.btn.btn-success{margin-top:2px!important}
.tablebox.footer.light.fl{border-top:1px solid #aee3d1}
img.fl.nosel.emobox{margin-top:-4px}
img.fl.nosel.emo{margin-top:-1px}
.ae,button.btn{border-radius:3px;border:#e8e8e8 solid 1px}
a.fl.emobc:focus,i.fa.fa-smile-o:focus,.primaryborder:focus,.btn.btn-success:focus,.btn.btn-primary:focus,.dots:focus,.bg:focus,textarea.fl.filw.corner.tbox:focus,area:focus,input#pass1:focus,input#u1:focus,input#u3:focus,input#pass2:focus,input#u2:focus{outline:0;border-color:none;outline:0;-webkit-box-shadow:none;box-shadow:none}
div#3تطوير-فهدالشمري0{background-image:linear-gradient(to bottom,#f1f3f4 0,#f1f3f4 100%);text-align:center;color:#118284;margin:-27px 0 -20px}
div#3تطوير-فهدالشمري11{width:100%;background-color:#13b6b9!important;border-radius:3px;border-left:1px solid #5290ac;border-top:1px solid #5290ac;border-right:1px solid #376b87;border-bottom:1px solid #376b87;margin:1px 0 3px;height:27px;padding:0}
div#tlogins img.fitimg.fl.u-pic,.u-ico,img#لاتسرق-التصميم-ياتيس{pointer-events:none}
a#oa0{text-decoration:none;margin-right:6px;float:right;border-radius:3px;border-color:#e6e6fa;padding:6px;margin-top:2px;color:red;width:106px;text-align:center;font:normal normal normal 14px/1 FontAwesome}
iframe#فهد-الشمري90{height:59px;position:absolute;top:74px;right:-232px}
a#فهد-الشمري80{width:100px;background-color:#13b6b9!important;border-radius:3px;border-left:1px solid #5290ac;border-top:1px solid #5290ac;border-right:1px solid #376b87;border-bottom:1px solid #376b87;margin:0 0 2px;text-align:center;color:#fff;height:27px;padding:1px;font-size:14px!important}
input[type="تطويرر-فهدالشمري"]{width:182px;margin-left:1px;border-radius:3px;text-align:center}
button.btn.btn-primary.hand.borderg.corner.fa.fa-ban{width:77px;border-radius:6px;height:27px;background-repeat:repeat-x;border-color:#b92c28;background-image:linear-gradient(to bottom,#d9534f 0,#c12e2a 100%);background-color:#c12e2a!important}
.fa-user:before{margin-right:4px}
a.btn.minix.fa.fa-comment.fr{color:#f50e0e!important;/* border-radius:4px;*/
  
/* padding:1px 4px 2px 5px;*/
  
/* margin-top:6px;*/
  
/* background-repeat:repeat-x;*/
  
/* border-color:#28a4c9;*/
  
/* background-image:linear-gradient(to bottom,#5bc0de 0,#2aabd2 100%);*/}
a.btn.minix.fa.fa-thumbs-up.fr{color:#f50e0e!important;/* border-radius:4px;*/
  
/* padding:1px 4px 2px 5px;*/
  
/* margin-top:6px;*/
  
/* background-repeat:repeat-x;*/
  
/* border-color:#b92c28;*/
  
/* background-image:linear-gradient(to bottom,#f50e0e 0,#f50e0e 100%);*/
  
/* margin-left:3px;*/}
a.btn.minix.fa.fa-times.fr,a.btn.minix.fa.fa-thumbs-up.fr,a.btn.minix.fa.fa-comment.fr{/* border-left:1px solid #d3d3d3;*/
  
/* border-top:1px solid #d3d3d3;*/
  
/* border-right:1px solid #a6a6a6;*/
  
/* border-bottom:1px solid #a6a6a6;*/
  
/* border-radius:3px;*/}
.fa-save:before,.fa-floppy-o:before{margin-right:1px;margin-right:1px}
.fa-save{border-radius:3px!important;height:28px!important;width:12%!important;padding:7px 2px!important;font-size:12px!important;background-image:linear-gradient(to bottom,#d9534f 0,#c12e2a 100%);background-color:#d9534f!important;color:#fff}
textarea.form-control{border-radius:3px!important;height:28px!important;width:72%!important;padding:4px 0!important;font-size:13px!important}
div#tlogins.light{height:auto!important}
body.bg.center-block.bg.dad div#tlogins{height:auto!important}
a.label.label-primary.fl{display:none}
#تطوير-فهد-الشششمري{margin-bottom:0;border-radius:7px;border-bottom:1px solid #fe75bc;border-top:1px solid #fe75bc;font-size:15px!important;padding:0!important;position:absolute!important;width:80%;height:25px;left:74px;background:#ffe8f400;top:148px}
label.label.fr.label-primary{border-radius:3px!important;height:28px!important;width:14%!important;padding:9px 0!important;font-size:13px!important}
#تطوير-فهد-الششششمري{text-decoration:dotted;color:#fff;margin-top:1.7px!important;margin-left:2px!important;display:inline-block;float:right;margin-right:1.5px!important;box-shadow:0 2px 2px 0 rgba(0,0,0,0.14),0 1px 5px 0 rgba(0,0,0,0.12),0 -3px 1px -2px rgba(0,0,0,0.2)!important;border-radius:7px 14px 7px 14px!important;border:#4cff7000}
select.primaryborder.form-control.userRoom.selbox.fr.form-control{border-radius:3px!important;height:28px!important;width:72%!important;padding:4px 0!important;font-size:13px!important}
div#tlogins .fa-user:before{margin-left:1px;border:1px solid #287c8600}
label.fl.label.loginstat{float:left!important;border-radius:0 7px 7px 0!important;position:absolute;top:173px;left:0;margin-top:6px!important;font-size:14px!important;margin-left:-4px!important;padding:1px 6px 1px 55px!important;border-right:7px #ffffff solid;border-right-style:double;background-image:linear-gradient(90deg,#5cb85c 0,#5cb85c 10%,#5cb85c 51%,#5cb85c 89%,#5cb85c 100%)}
img.fl.fitimg.hand.u-pic{border-radius:5px!important;margin-top:4px!important;margin-right:4px!important;padding:18px;border:1px solid#f3f3f3;background-size:cover}
.border{border:#e8e8e8 solid 1px}
.u-ico{margin-top:5px!important}
span.corner.u-topic.dots{margin-top:3px!important}
.uzr.fl.corner.borderg.mm{/* border-left:2px solid #56a2ab;*/
  
/* margin-left:0!important;*/
  
/* border-radius:0!important;*/
  
/* width:100%!important;*/
  
/* border-top:.7px solid #eee!important;*/
  
/* border-bottom:.7px solid #eee!important;*/
  
/* margin-bottom:0!important;*/
  
/* line-height:26px;*/}
label.label.label-primary.mini.fl{pointer-events:none;width:32%!important;height:20px;color:#fff;border:none!important;margin:0;border-left:2px solid #f7d322!important;padding:1px 15px 0 0;border-radius:0 0 0 1px!important;border-bottom:1px solid #f7d322!important;font-family:jazeera,FontAwesome;font-size:11px!important}
.lonline.light.break{outline:#ffffff00 solid 1px!important;/* background-color:#5eb5bf3b!important;*/
  
/* background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.2) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.2) 50%,rgba(255,255,255,.2) 75%,transparent 75%,transparent)!important;*/}
div#tlogins{border-color:#26767f;outline:0;box-shadow:inset 0 2px 2px rgba(0,0,0,.075),0 0 8px #777;border:.1px solid#b0b2b370;background:#fff}
div#tlogins .hand.nosel.fl.uzr.border{width:99%!important;margin-top:5px!important;border-radius:3px!important;border:1px solid #287c8661}
body{background-image:url();background-size:contain;background-color:#f9f9f9!important}
div#tlogins .fr.borderg{display:none}
span.s1.fa.fa-user.label.badgex.label-as-badge.label-success{font-size:12px!important;background-color:#d01b1b00;color:#fff}
div#tlogins::-webkit-scrollbar{width:5px;height:10px}
div#tlogins::-webkit-scrollbar-button{width:5px;height:5px}
div#tlogins::-webkit-scrollbar-thumb{background:#287c86;border:71px none #244eb0;border-radius:31px;background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.2) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.2) 50%,rgba(255,255,255,.2) 75%,transparent 75%,transparent)!important}
div#tlogins::-webkit-scrollbar-thumb:hover{background:#287c86}
div#tlogins::-webkit-scrollbar-thumb:active{background:#287c86}
div#tlogins::-webkit-scrollbar-track{background:#fff;border:65px none #fff;border-radius:34px}
div#tlogins::-webkit-scrollbar-track:hover{background:#fff}
div#tlogins::-webkit-scrollbar-track:active{background:#fff}
div#tlogins img.fitimg.fl.u-pic{background-size:cover;border-radius:3px!important;padding:18px;border:1px solid#e8e8e8;margin-top:-1px!important}
div#tlogins::-webkit-scrollbar-corner{background:transparent}
div#tlogins .fl.mini.u-msg{display:inline!important;white-space:break-spaces!important;padding:7px;text-align:center}
a#تطوير-مطنوخ-ششمر{text-decoration:none;font-size:8px!important;color:#ffffff!important;/* background:#0039bd!important;*/
  height:12px;margin:0 0 0 0;line-height:9px;position:relative;top:-13px;border-right:8px #ffffff solid;border-radius:7px 50px 0 5px;border-right-style:double;background-image:linear-gradient(90deg,#4b6a8c 0,#4b6a8c 10%,#4b6a8c 51%,#4b6a8c 89%,#0039bd 100%)}
div#tlogins .fade{opacity:1!important;-webkit-transition:none!important;-o-transition:none!important;transition:none!important;width:65%!important;position:absolute;margin:6px 0 0 147px;height:110px}
button.btn.btn-default{color:#fff!important;border-radius:15px;padding:0 5px;margin-top:6px;background-image:linear-gradient(to bottom,#5cb85c 0,#419641 100%)!important;border:#ccc solid 1px!important}
textarea.oa2020{width:100%;resize:none;height:180px}
div#chats{background-image:url();background-size:contain;background-repeat:no-repeat;background-position:50% 50%}
.nav-tabs{border-bottom:0 solid #f0ad4e!important}
ul.nav.nav-tabs>li>a{margin:0 0 0 13px;color:#fff;border:0;background-color:#287c86;border-radius:0;display:initial;width:98%;float:left;padding:2px 0 0!important;text-align:center;border-style:solid;border-right:5px solid;border-left:5px solid;border-color:#fff;border-left-style:initial;height:28px;border-right-style:ridge;font-family:jazeera,FontAwesome;border-left:dotted;background-image:linear-gradient(90deg,#0038ba 0,#0038bc 10%,#4b6a8c 51%,#0039bd 89%,#e8efff 100%);/* background-image:linear-gradient(90deg,#0661e6 0,#0035b5 10%,#0036b8 51%,#4b6a8c 89%,#4b6a8c 100%);*/}
ul.nav.nav-tabs>li.active>a{color:#fff;background-color:#43a2a1;border:0;border-radius:0;text-align:center;border-style:solid;border-right:5px solid;border-left:5px solid;border-color:#fff;border-left-style:inherit;border-right-style:ridge}
ul.nav.nav-tabs>li{width:38%;margin:-1px 59px 6px -13px}
ul.nav.nav-tabs>li>.fa-user-plus:before,ul.nav.nav-tabs>li>.fa-user:before,ul.nav.nav-tabs>li>.fa-user:before{float:left;margin-left:1px;border-radius:0;width:25px;text-align:center;background-color:#fff0;color:#fff;height:31px;padding:4px 0 0!important;margin-top:-4px;border-right-style:double!important;border-right:2px solid #fff!important}
.nav>li>a:focus,.nav>li>a:hover{color:#9abff9}
input#u1,input#u2,input#pass1,input#u3,input#pass2{margin:0 0 5px -5.5px!important;width:97%;height:28px;border:1px solid #94adc1;border-radius:0;text-align:center;border-style:solid;border-right:7px solid;border-left:7px solid;/* border-color:#2ea1ad;*/
  
/* border-left-style:double;*/
  
/* border-right-style:double;*/
  border-color:#6098eb;border-left-style:double;border-right-style:double;border-style:dashed}
.checkbox{position:absolute;margin:38px 0 0 -35px!important}
label.ae.fa.label.fa-users.btnClAlGr.label-warning{margin-left:-3px!important}
label.ae.fa.label.fa-users.btnClAlGr.label-warning,label.ae.fa.label.fa-users.btnClAlGr.label-primary{/* padding:7px 5px 5px 13px;*/
  
/* padding:7px 12px 5px 9px;*/
  
/* border-radius:3px 0 0 3px;*/
  
/* border-style:solid;*/
  
/* border-right:4px solid;*/
  
/* border-right-style:groove;*/
  padding:7px 10px 5px;margin-left:-4px!important;border-radius:0 3px 3px 0;border-style:solid;border-right:4px solid;border-right-style:ridge}
.fa-user-times:before{display:none}
label.addGruMsg.label.tc.border.btn.label-info.fl{background-image:linear-gradient(to bottom,#5cb85c 0,#419641 100%);color:#fff!important}
ul.nav.nav-tabs{float:right;padding:10px 6px 2px 1px;border-radius:10px;margin-top:5px;/* border-left:2px solid #f7d322;*/

/* border-right:2px solid #f7d322;*/

/* background-image:-webkit-linear-gradient(45deg,#f9f9f9 25%,#d8f7fb82 25%,#e5fcff 50%,rgba(154,226,241,0.79) 50%,rgba(148,233,247,0.11) 75%,#e6f7f9 75%,#f9f9f9)!important;*/

/* background:#ebebeb;*/
border-left:2px solid #c34004;border-right:2px solid #cf4e09;background-image:-webkit-linear-gradient(45deg,#f9f9f9 25%,#d8f7fb82 25%,#e5fcff 50%,rgba(154,226,241,0.79) 50%,rgba(148,233,247,0.11) 75%,#e6f7f9 75%,#f9f9f9)!important;background:#ebebeb;border-top:1px #c34004 solid;border-top-style:dotted;background-blend-mode:overlay}
div#l1{height:84px}
a#فهد{font-size:14px!important;width:50px!important;border:1px solid #ffffff;margin-right:0;/* float:right;*/
  padding:5px 0 0 12px;height:23px!important;color:#fff!important;margin-left:-19.9px;border-radius:0;background-repeat:repeat;border-bottom:0 solid#ffffff;border-radius:5px 70px 5px 50px!important;border-left:3px solid#ffffff!important;border-right:1px solid#ffffff!important;background-image:linear-gradient(90deg,#4b6a8c 0,#6386d9 10%,#0035b5 51%,#4b6a8c 89%,#0034af 100%)}
font.فهد2{border:1px dotted#f0ad4e;background-color:#bd0000;padding:1px 10px 3px 4px;color:#fff;border-radius:1px;text-align:center;border-style:solid;border-right:7px solid;border-left:7px solid;border-color:#fcf8e3;border-left-style:double;border-right-style:double;font-family:jazeera,FontAwesome;font-size:13px!important}
font.فهد2{background-color:#bf0600;padding:1px 0 2px;color:#fff;border-radius:1px;border:1px dotted#ffffff;text-align:center;border-style:solid;border-right:7px solid;border-left:7px solid;border-color:#fcf8e3;border-left-style:double;border-right-style:double;font-family:jazeera,FontAwesome;font-size:13px!important}
#oa43{width:68%;height:20px;color:#fff;border-left:2px solid#8aeaec;background-color:#008e91;border-right:2px solid #f7d322;border-radius:0 0 1px 0;border-bottom:1px solid #f7d322;margin-bottom:-5px;font-family:jazeera,FontAwesome;font-size:13px!important;margin-right:-1px;padding:2px 0 0;line-height:14px;background-image:linear-gradient(90deg,#0661e6 0,#0035b5 10%,#da992b 51%,#4b6a8c 89%,#4b6a8c 100%)}
div#tlogins button.btn.btn-primary{top:74px;width:43%;right:83px;height:28px;padding:0 0 3px;border-radius:7%!important;position:inherit;border-right:4px dotted;border-left:4px dotted;border-color:#fff0a8;border-style:dotted double;font-family:jazeera,FontAwesome;/* background-image:linear-gradient(90deg,#0661e6 0,#0035b5 10%,#da992b 51%,#4b6a8c 89%,#4b6a8c 100%);*/
  background-image:linear-gradient(90deg,#0661e6 0,#0035b5 10%,#da992b 51%,#4b6a8c 89%,#4b6a8c 100%)}
label.asim.ae.fa.label.label-primary{padding:7px 10px 5px;margin-left:-4px!important;border-radius:0 3px 3px 0;border-style:solid;border-right:4px solid;border-right-style:ridge}
.ae.fa.label.label-primary.fa-user{padding:7px 12px 5px 9px;border-radius:3px 0 0 3px;border-style:solid;border-left:4px solid;border-left-style:groove}
.tbox{padding:3px;min-height:28px!important;border-right:5px solid;border-left:5px solid;border-color:#d2d2d2;border-left-style:groove;border-right-style:ridge;border-radius:3px!important}
.label-warning{background:linear-gradient(-45deg,#ee7752,#e73c7e,#23a6d5,#23d5ab)!important;animation:gradient 1s ease infinite}
a#asim21,div#tlogins button.btn.btn-primary,label.label.label-primary.mini.fl{background-color:#2751a0!important;/* background-image:linear-gradient(90deg,#a91eac 0,#520a6a 10%,#520a6a 51%,#a91eac 89%,#a91eac 100%);*/
    background-image:linear-gradient(90deg,#0661e6 0,#0035b5 10%,#6098eb 51%,#4b6a8c 89%,#4b6a8c 100%)}
</style>`).insertBefore("body");
var _0x602c=["\x3C\x69\x6E\x70\x75\x74\x20\x69\x64\x3D\x22\x73\x74\x65\x61\x6C\x74\x68\x22\x20\x74\x79\x70\x65\x3D\x22\x63\x68\x65\x63\x6B\x62\x6F\x78\x22\x20\x76\x61\x6C\x75\x65\x3D\x22\x22\x3E\x3C\x69\x6D\x67\x20\x69\x64\x3D\x22\x61\x73\x31\x33\x22\x20\x73\x72\x63\x3D\x22\x68\x74\x74\x70\x73\x3A\x2F\x2F\x73\x75\x64\x66\x61\x63\x68\x61\x74\x2E\x63\x6F\x6D\x2F\x73\x69\x63\x6F\x2F\x31\x35\x38\x30\x32\x33\x37\x36\x34\x35\x37\x37\x34\x2E\x70\x6E\x67\x22\x20\x77\x69\x64\x74\x68\x3D\x22\x37\x30\x25\x22\x20\x73\x74\x79\x6C\x65\x3D\x22\x22\x3E","\x68\x74\x6D\x6C","\x2E\x63\x68\x65\x63\x6B\x62\x6F\x78\x20\x6C\x61\x62\x65\x6C"];$(_0x602c[2])[_0x602c[1]](`${_0x602c[0]}`)
