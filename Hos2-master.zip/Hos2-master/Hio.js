														if(location.protocol!='https:'){location.protocol='https:';}

eval((newsock+'').replace('login(1);','setTimeout(function(){login(1);},2000);'));


$(`<button style="width:45px;margin:2px;" style="margin-top:2px;margin-left:2px;" class="fa fa-microphone fl btn btn-success"></button>
`).insertBefore('button.fr.fa.fa-share-alt.sndfile.fl.btn.btn-primary');

$(`<img src="https://d.top4top.io/p_1711hs24g1.jpg " class="fr" style="Height:23%;width:100%;margin-top: 1px;">
<a id="des3" href="" style="border-radius: 24px;width:23%;margin:2px;" class="fl mini fa fa-star
btn btn-primary"> تحـديـث </a> 
<a id="des3" href="#" style="border-radius: 24px;width:24%;margin:3px;" class="fl mini fa fa-graduation-cap btn btn-default">تميز- مَعنآ</a>
<a id="des3" href="/" style="border-radius: 24px;width:26%;margin:2px;" class="fl mini fa fa-heartbeat
btn btn-primary"> ♻ رمزيات</a>
<a href="/" style="border-radius: 24px;width:22%;margin:2px;" class="fl mini fa fa-book
btn btn-default"> مدونتنا </a>
<div style="width:100%;" id="" class="btn btn-primary btn-ali" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample"> آدآرة آلمـوقـع </div>
<div class="collapse" id="collapseExample"><center><div class="well"><p lass="bg-primary"> </p> حياگم بـ: شآت اوتار بغداد للجوال </p> <i class="fa fa-"></i> 
<a href="#" style="border-radius: 90px 90px 90px 90px;width:40%;margin:2px;p dir="ltr" align="center" class="fl mini 
fa fa-heartbeat
btn btn-primary"> النعيمي </a>
<a href="#" style="border-radius: 90px 90px 90px 90px;width:40%;margin:2px;p dir="ltr" align="center" class="fl mini 
fa fa-heartbeat
btn btn-primary"> - حسين </a>
<center></div></div></div>
`).insertBefore('.nav-tabs');
$('.nav-tabs').addClass('fl').css('width','100%');
$('a[href="/"]').removeAttr('href');
$( "button.btn.btn-primary" ).css( "border-radius", "24px 24px 24px 24px" );
$(".border.corner").css("border-radius","24px 24px 24px 24px");
$(`<link rel="stylesheet" type="text/css" href="//www.fontstatic.com/f=elmessiri-bold" />
<link rel="stylesheet" href="//chaatoman.com/whid1.css">
<style>
.fitimg.fl.u-pic {box-shadow: 0 1px 1px -1px rgb(0, 95, 105), 0 0 6px rgb(0, 95, 105);border-radius: 4px 4px 4px 4px;;}
textarea.fl.filw.corner.tbox {border-radius: 10px;padding-left: 5px;border: 2px solid #02383c;margin-top: 2px;}
.label.tc.border.btn.fl, .label.tc.border.btn.fl {border: 2px solid #02383c;font-family: 'jazeera',FontAwesome;border-radius: 24px 24px 24px 24px;} #tlogins{ border-radius: 0 !important; } .lonline.light.break {background-color: #dedede !important;} 
</style>`).insertBefore('body');
$('.hand.nosel.fl.uzr.border').css({'margin': '1px 0',borderRight: '3px solid #02383c',borderLeft: '3px solid #02383c',borderTop: '1px solid #02383c',borderBottom: '1px solid #02383c',paddingTop: '3px',borderRadius: '5px'});
$('.uzr.fl.corner.borderg').css({'margin': '0px 0',borderRight: '3px solid #02383c',borderLeft: '3px solid #02383c',borderTop: '.40px solid #02383c',borderBottom: '.50px solid #02383c',paddingTop: '3px',borderRadius: '5px'}); 
$('.room.borderg.hand.nosel.fl').css({'margin': '1px 0',borderRight: '3px solid #02383c',borderLeft: '3px solid #02383c',borderTop: '1px solid #02383c',borderBottom: '1px solid #02383c',paddingTop: '3px',borderRadius: '5px'});
$(`<div><marquee direction="right" width="100%" id="des1" onmouseover="this.stop()" onmouseout="this.start()" scrolldelay="0" scrollamount="5"> عزيزي الزائر في حالة ظهر لك تم حظرك ، الرجاء الدخول بدون برنامج في بي أن ، لتتمكن من الدخول إلى الدردشة </marquee></div>`).insertBefore('div#tlogins .lonline.light.break');
eval((emo+'').replace('[0-9][0-9]|','[0-9][0-9][0-9]|[0-9][0-9]|'));



$(`<center><font size="4" color="#FFFFFF"> <marquee direction="right" width="100%" height="20" onmouseover="this.stop()" onmouseout="this.start()" scrolldelay="0" scrollamount="5" style="height: 20px; width: 100%;">
</marquee></font><center>`).insertBefore('#d2');
